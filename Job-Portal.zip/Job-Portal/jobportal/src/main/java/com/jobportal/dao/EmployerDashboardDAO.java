package com.jobportal.dao;

import com.jobportal.db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EmployerDashboardDAO {

    // =========================================================
    // GET TOTAL JOBS POSTED BY EMPLOYER
    // =========================================================

    public int getTotalJobs(int employerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOBS " +
                "WHERE EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET TOTAL JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // GET ACTIVE JOBS
    // =========================================================
    //
    // JOBS table currently does not have STATUS.
    // Therefore all jobs posted by the employer
    // are considered active.
    // =========================================================

    public int getActiveJobs(int employerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOBS " +
                "WHERE EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET ACTIVE JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // GET TOTAL APPLICATIONS RECEIVED
    // =========================================================

    public int getTotalApplications(int employerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOB_APPLICATIONS a " +
                "JOIN JOBS j " +
                "ON a.JOB_ID = j.JOB_ID " +
                "WHERE j.EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET TOTAL APPLICATIONS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // GET SHORTLISTED CANDIDATES
    // =========================================================
    //
    // JOB_APPLICATIONS contains STATUS.
    // So now we can get the real shortlisted count.
    // =========================================================

    public int getShortlistedCandidates(int employerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOB_APPLICATIONS a " +
                "JOIN JOBS j " +
                "ON a.JOB_ID = j.JOB_ID " +
                "WHERE j.EMPLOYER_ID = ? " +
                "AND UPPER(a.STATUS) = 'SHORTLISTED'";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET SHORTLISTED CANDIDATES ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // GET RECENT APPLICATIONS
    // =========================================================
    //
    // Gets latest applications for jobs belonging
    // to the logged-in employer.
    //
    // USERS -> candidate name
    // JOBS -> job title
    // JOB_APPLICATIONS -> date + status
    // =========================================================

    public ResultSet getRecentApplications(
            Connection con,
            int employerId) throws Exception {

        String sql =
                "SELECT * " +
                "FROM ( " +
                "    SELECT " +
                "        a.APP_ID, " +
                "        u.NAME AS CANDIDATE_NAME, " +
                "        j.TITLE AS JOB_TITLE, " +
                "        a.APPLY_DATE, " +
                "        a.STATUS " +
                "    FROM JOB_APPLICATIONS a " +
                "    JOIN JOBS j " +
                "        ON a.JOB_ID = j.JOB_ID " +
                "    JOIN USERS u " +
                "        ON a.SEEKER_ID = u.USER_ID " +
                "    WHERE j.EMPLOYER_ID = ? " +
                "    ORDER BY a.APPLY_DATE DESC " +
                ") " +
                "WHERE ROWNUM <= 5";

        PreparedStatement ps =
                con.prepareStatement(sql);

        ps.setInt(1, employerId);

        return ps.executeQuery();
    }


    // =========================================================
    // GET RECENT JOB POSTINGS
    // =========================================================
    //
    // Gets latest jobs posted by the logged-in employer.
    //
    // Also calculates how many applications each job received.
    // =========================================================

    public ResultSet getRecentJobPostings(
            Connection con,
            int employerId) throws Exception {

        String sql =
                "SELECT * " +
                "FROM ( " +
                "    SELECT " +
                "        j.JOB_ID, " +
                "        j.TITLE, " +
                "        j.LOCATION, " +
                "        j.POSTED_DATE, " +
                "        ( " +
                "            SELECT COUNT(*) " +
                "            FROM JOB_APPLICATIONS a " +
                "            WHERE a.JOB_ID = j.JOB_ID " +
                "        ) AS APPLICATION_COUNT " +
                "    FROM JOBS j " +
                "    WHERE j.EMPLOYER_ID = ? " +
                "    ORDER BY j.POSTED_DATE DESC " +
                ") " +
                "WHERE ROWNUM <= 5";

        PreparedStatement ps =
                con.prepareStatement(sql);

        ps.setInt(1, employerId);

        return ps.executeQuery();
    }
}