package com.jobportal.servlet;

import com.jobportal.dao.JobDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/DeleteJobServlet")
public class DeleteJobServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // =========================================
        // SESSION
        // =========================================

        HttpSession session =
                request.getSession(false);

        if (session == null) {

            response.setStatus(
                HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Session expired. Please login again.\"}"
            );

            return;
        }

        Object obj =
                session.getAttribute("loggedUser");

        if (obj == null) {

            response.setStatus(
                HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter().print(
                "{\"success\":false,\"message\":\"User not logged in.\"}"
            );

            return;
        }

        User loggedUser = (User) obj;

        int employerId =
                loggedUser.getUserId();

        // =========================================
        // GET JOB ID
        // =========================================

        String jobIdParam =
                request.getParameter("jobId");

        if (jobIdParam == null ||
            jobIdParam.trim().isEmpty()) {

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Job ID is required.\"}"
            );

            return;
        }

        int jobId;

        try {

            jobId =
                Integer.parseInt(jobIdParam);

        } catch (NumberFormatException e) {

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Invalid Job ID.\"}"
            );

            return;
        }

        System.out.println(
            "Delete Job - Employer ID: "
            + employerId
            + " Job ID: "
            + jobId
        );

        // =========================================
        // DELETE
        // =========================================

        JobDAO dao = new JobDAO();

        boolean success =
                dao.deleteJob(
                    jobId,
                    employerId
                );

        // =========================================
        // RESPONSE
        // =========================================

        if (success) {

            response.getWriter().print(
                "{\"success\":true,\"message\":\"Job deleted successfully.\"}"
            );

        } else {

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Unable to delete job.\"}"
            );
        }
    }
}