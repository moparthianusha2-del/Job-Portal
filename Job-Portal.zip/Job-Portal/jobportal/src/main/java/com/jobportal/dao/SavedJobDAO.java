package com.jobportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.jobportal.db.DBConnection;
import com.jobportal.model.SavedJob;

public class SavedJobDAO {

    // =========================================================
    // SAVE JOB
    // =========================================================

    public boolean saveJob(int userId, int jobId) {

        String sql =
                "INSERT INTO SAVED_JOBS " +
                "(SAVE_ID, USER_ID, JOB_ID, SAVED_DATE) " +
                "VALUES " +
                "(SAVED_JOBS_SEQ.NEXTVAL, ?, ?, SYSDATE)";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, userId);
            ps.setInt(2, jobId);

            int rows = ps.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }


    // =========================================================
    // CHECK WHETHER JOB IS ALREADY SAVED
    // =========================================================

    public boolean isJobSaved(int userId, int jobId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM SAVED_JOBS " +
                "WHERE USER_ID = ? AND JOB_ID = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, userId);
            ps.setInt(2, jobId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return false;
    }


    // =========================================================
    // GET SAVED JOBS FOR USER
    // =========================================================

    public List<SavedJob> getSavedJobsByUser(int userId) {

        List<SavedJob> savedJobs = new ArrayList<>();

        String sql =
                "SELECT s.SAVE_ID, " +
                "       s.USER_ID, " +
                "       s.JOB_ID, " +
                "       s.SAVED_DATE, " +
                "       j.TITLE, " +
                "       j.DESCRIPTION, " +
                "       j.LOCATION " +
                "FROM SAVED_JOBS s " +
                "JOIN JOBS j ON s.JOB_ID = j.JOB_ID " +
                "WHERE s.USER_ID = ? " +
                "ORDER BY s.SAVED_DATE DESC";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, userId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                SavedJob savedJob = new SavedJob();

                savedJob.setSaveId(
                        rs.getInt("SAVE_ID")
                );

                savedJob.setUserId(
                        rs.getInt("USER_ID")
                );

                savedJob.setJobId(
                        rs.getInt("JOB_ID")
                );

                savedJob.setSavedDate(
                        rs.getDate("SAVED_DATE")
                );

                savedJob.setJobTitle(
                        rs.getString("TITLE")
                );

                savedJob.setDescription(
                        rs.getString("DESCRIPTION")
                );

                savedJob.setLocation(
                        rs.getString("LOCATION")
                );

                savedJobs.add(savedJob);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return savedJobs;
    }


    // =========================================================
    // REMOVE SAVED JOB
    // =========================================================

    public boolean removeSavedJob(int userId, int jobId) {

        String sql =
                "DELETE FROM SAVED_JOBS " +
                "WHERE USER_ID = ? AND JOB_ID = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, userId);
            ps.setInt(2, jobId);

            int rows = ps.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}