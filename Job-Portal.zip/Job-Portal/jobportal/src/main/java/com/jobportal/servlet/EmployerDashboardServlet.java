package com.jobportal.servlet;

import com.jobportal.dao.EmployerDashboardDAO;
import com.jobportal.model.User;
import com.jobportal.db.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/EmployerDashboardServlet")
public class EmployerDashboardServlet extends HttpServlet {

    private EmployerDashboardDAO dashboardDAO;


    // =========================================================
    // INITIALIZE DAO
    // =========================================================

    @Override
    public void init() throws ServletException {

        dashboardDAO =
                new EmployerDashboardDAO();

        System.out.println(
                "EmployerDashboardServlet initialized successfully."
        );
    }


    // =========================================================
    // GET EMPLOYER DASHBOARD DATA
    // =========================================================

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out =
                response.getWriter();


        // =====================================================
        // GET LOGIN SESSION
        // =====================================================

        HttpSession session =
                request.getSession(false);


        if (session == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            out.print(
                    "{"
                    + "\"success\":false,"
                    + "\"message\":\"Session expired. Please login again.\""
                    + "}"
            );

            return;
        }


        // =====================================================
        // GET LOGGED-IN USER
        // =====================================================

        Object loggedUserObject =
                session.getAttribute("loggedUser");


        if (loggedUserObject == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            out.print(
                    "{"
                    + "\"success\":false,"
                    + "\"message\":\"User is not logged in.\""
                    + "}"
            );

            return;
        }


        // =====================================================
        // CHECK USER OBJECT
        // =====================================================

        if (!(loggedUserObject instanceof User)) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            out.print(
                    "{"
                    + "\"success\":false,"
                    + "\"message\":\"Invalid login session.\""
                    + "}"
            );

            return;
        }


        User loggedUser =
                (User) loggedUserObject;


        int employerId =
                loggedUser.getUserId();


        // =====================================================
        // CHECK EMPLOYER ROLE
        // =====================================================

        if (
                loggedUser.getRole() == null ||
                !loggedUser.getRole()
                           .equalsIgnoreCase("EMPLOYER")
        ) {

            response.setStatus(
                    HttpServletResponse.SC_FORBIDDEN
            );

            out.print(
                    "{"
                    + "\"success\":false,"
                    + "\"message\":\"Employer account required.\""
                    + "}"
            );

            return;
        }


        System.out.println(
                "========================================"
        );

        System.out.println(
                "Employer Dashboard"
        );

        System.out.println(
                "Employer ID: " + employerId
        );

        System.out.println(
                "Employer Name: "
                + loggedUser.getFullname()
        );

        System.out.println(
                "Company: "
                + loggedUser.getCompany()
        );

        System.out.println(
                "========================================"
        );


        // =====================================================
        // GET DASHBOARD COUNTS
        // =====================================================

        int totalJobs =
                dashboardDAO.getTotalJobs(
                        employerId
                );

        int activeJobs =
                dashboardDAO.getActiveJobs(
                        employerId
                );

        int totalApplications =
                dashboardDAO.getTotalApplications(
                        employerId
                );

        int shortlistedCandidates =
                dashboardDAO.getShortlistedCandidates(
                        employerId
                );


        // =====================================================
        // BUILD RECENT APPLICATIONS JSON
        // =====================================================

        StringBuilder recentApplications =
                new StringBuilder();

        recentApplications.append("[");


        // =====================================================
        // BUILD RECENT JOBS JSON
        // =====================================================

        StringBuilder recentJobs =
                new StringBuilder();

        recentJobs.append("[");


        try (
                Connection con =
                        DBConnection.getConnection()
        ) {


            // =================================================
            // RECENT APPLICATIONS
            // =================================================

            try (
                    ResultSet rs =
                            dashboardDAO.getRecentApplications(
                                    con,
                                    employerId
                            )
            ) {

                boolean first =
                        true;

                while (rs.next()) {

                    if (!first) {
                        recentApplications.append(",");
                    }

                    first = false;


                    recentApplications.append("{");


                    recentApplications.append(
                            "\"appId\":"
                    )
                    .append(
                            rs.getInt("APP_ID")
                    )
                    .append(",");


                    recentApplications.append(
                            "\"candidate\":\""
                    )
                    .append(
                            escapeJson(
                                    rs.getString(
                                            "CANDIDATE_NAME"
                                    )
                            )
                    )
                    .append("\",");


                    recentApplications.append(
                            "\"jobTitle\":\""
                    )
                    .append(
                            escapeJson(
                                    rs.getString(
                                            "JOB_TITLE"
                                    )
                            )
                    )
                    .append("\",");


                    Date applyDate =
                            rs.getDate(
                                    "APPLY_DATE"
                            );


                    String formattedDate =
                            "";


                    if (applyDate != null) {

                        formattedDate =
                                new SimpleDateFormat(
                                        "dd-MMM-yyyy"
                                )
                                .format(applyDate);
                    }


                    recentApplications.append(
                            "\"appliedDate\":\""
                    )
                    .append(
                            formattedDate
                    )
                    .append("\",");


                    recentApplications.append(
                            "\"status\":\""
                    )
                    .append(
                            escapeJson(
                                    rs.getString(
                                            "STATUS"
                                    )
                            )
                    )
                    .append("\"");


                    recentApplications.append("}");
                }
            }


            // =================================================
            // RECENT JOB POSTINGS
            // =================================================

            try (
                    ResultSet rs =
                            dashboardDAO.getRecentJobPostings(
                                    con,
                                    employerId
                            )
            ) {

                boolean first =
                        true;

                while (rs.next()) {

                    if (!first) {
                        recentJobs.append(",");
                    }

                    first = false;


                    recentJobs.append("{");


                    recentJobs.append(
                            "\"jobId\":"
                    )
                    .append(
                            rs.getInt("JOB_ID")
                    )
                    .append(",");


                    recentJobs.append(
                            "\"title\":\""
                    )
                    .append(
                            escapeJson(
                                    rs.getString("TITLE")
                            )
                    )
                    .append("\",");


                    recentJobs.append(
                            "\"location\":\""
                    )
                    .append(
                            escapeJson(
                                    rs.getString("LOCATION")
                            )
                    )
                    .append("\",");


                    recentJobs.append(
                            "\"applications\":"
                    )
                    .append(
                            rs.getInt(
                                    "APPLICATION_COUNT"
                            )
                    )
                    .append(",");


                    // JOBS table has no STATUS column.
                    // Therefore all jobs are displayed as Active.

                    recentJobs.append(
                            "\"status\":\"Active\""
                    );


                    recentJobs.append("}");
                }
            }


        } catch (Exception e) {

            System.out.println(
                    "========== DASHBOARD DATA ERROR =========="
            );

            e.printStackTrace();
        }


        recentApplications.append("]");
        recentJobs.append("]");


        // =====================================================
        // SEND COMPLETE JSON RESPONSE
        // =====================================================

        out.print("{");


        // SUCCESS

        out.print(
                "\"success\":true,"
        );


        // =====================================================
        // CARDS
        // =====================================================

        out.print(
                "\"totalJobs\":"
                + totalJobs
                + ","
        );

        out.print(
                "\"activeJobs\":"
                + activeJobs
                + ","
        );

        out.print(
                "\"totalApplications\":"
                + totalApplications
                + ","
        );

        out.print(
                "\"shortlistedCandidates\":"
                + shortlistedCandidates
                + ","
        );


        // =====================================================
        // RECENT APPLICATIONS
        // =====================================================

        out.print(
                "\"recentApplications\":"
        );

        out.print(
                recentApplications
        );

        out.print(",");


        // =====================================================
        // RECENT JOBS
        // =====================================================

        out.print(
                "\"recentJobs\":"
        );

        out.print(
                recentJobs
        );


        out.print("}");


        System.out.println(
                "Employer dashboard data sent successfully."
        );
    }


    // =========================================================
    // ESCAPE JSON
    // =========================================================

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}