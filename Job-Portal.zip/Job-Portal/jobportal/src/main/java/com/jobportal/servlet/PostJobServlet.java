package com.jobportal.servlet;

import com.jobportal.dao.JobDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/PostJobServlet")
public class PostJobServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // =========================================
        // GET LOGGED-IN USER
        // =========================================

        HttpSession session = request.getSession(false);

        if (session == null) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Session expired. Please login again.\"}"
            );

            return;
        }

        Object obj = session.getAttribute("loggedUser");

        if (obj == null) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            response.getWriter().print(
                "{\"success\":false,\"message\":\"User not logged in.\"}"
            );

            return;
        }

        User loggedUser = (User) obj;

        int employerId = loggedUser.getUserId();

        System.out.println(
            "Post Job - Employer ID: " + employerId
        );

        // =========================================
        // GET FORM DATA
        // =========================================

        String title = request.getParameter("jobTitle");
        String description = request.getParameter("description");
        String location = request.getParameter("location");

        // =========================================
        // VALIDATION
        // =========================================

        if (title == null || title.trim().isEmpty()) {

            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Job title is required.\"}"
            );

            return;
        }

        if (description == null || description.trim().isEmpty()) {

            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Job description is required.\"}"
            );

            return;
        }

        // =========================================
        // INSERT JOB
        // =========================================

        JobDAO dao = new JobDAO();

        boolean success = dao.postJob(
            title.trim(),
            description.trim(),
            location == null ? "" : location.trim(),
            employerId
        );

        // =========================================
        // RESPONSE
        // =========================================

        PrintWriter out = response.getWriter();

        if (success) {

            response.setStatus(HttpServletResponse.SC_OK);

            out.print(
                "{\"success\":true,\"message\":\"Job posted successfully.\"}"
            );

        } else {

            response.setStatus(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            out.print(
                "{\"success\":false,\"message\":\"Unable to insert job into database. Check server console for the Oracle error.\"}"
            );
        }
    }
}