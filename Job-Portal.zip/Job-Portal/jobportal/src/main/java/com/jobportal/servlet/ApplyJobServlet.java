package com.jobportal.servlet;

import com.jobportal.dao.ApplicationDAO;
import com.jobportal.model.Application;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/ApplyJobServlet")
@MultipartConfig
public class ApplyJobServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        try {

            System.out.println("=================================");
            System.out.println("       APPLY JOB REQUEST");
            System.out.println("=================================");


            // =====================================================
            // 1. GET CURRENT LOGGED-IN USER FROM SESSION
            // =====================================================

            HttpSession session =
                    request.getSession(false);


            if (session == null) {

                System.out.println(
                        "ERROR: No active session"
                );

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                response.getWriter().print(
                        "not_logged_in"
                );

                return;
            }


            // =====================================================
            // 2. GET loggedUser FROM SESSION
            // =====================================================

            Object loggedUserObject =
                    session.getAttribute("loggedUser");


            if (loggedUserObject == null) {

                System.out.println(
                        "ERROR: loggedUser not found in session"
                );

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                response.getWriter().print(
                        "user_not_found"
                );

                return;
            }


            // =====================================================
            // 3. CONVERT SESSION OBJECT TO USER
            // =====================================================

            User loggedUser;


            try {

                loggedUser =
                        (User) loggedUserObject;

            } catch (ClassCastException e) {

                System.out.println(
                        "ERROR: Invalid loggedUser session object"
                );

                response.setStatus(
                        HttpServletResponse.SC_INTERNAL_SERVER_ERROR
                );

                response.getWriter().print(
                        "invalid_user_session"
                );

                return;
            }


            // =====================================================
            // 4. GET USER ID FROM LOGGED-IN USER
            // =====================================================

            int seekerId =
                    loggedUser.getUserId();


            System.out.println(
                    "================================="
            );

            System.out.println(
                    "LOGGED-IN USER DETAILS"
            );

            System.out.println(
                    "User ID = "
                    + loggedUser.getUserId()
            );

            System.out.println(
                    "Name = "
                    + loggedUser.getFullname()
            );

            System.out.println(
                    "Email = "
                    + loggedUser.getEmail()
            );

            System.out.println(
                    "Role = "
                    + loggedUser.getRole()
            );

            System.out.println(
                    "Seeker ID used for application = "
                    + seekerId
            );

            System.out.println(
                    "================================="
            );


            // =====================================================
            // 5. CHECK USER ROLE
            // =====================================================

            if (loggedUser.getRole() == null ||
                !loggedUser.getRole()
                    .equalsIgnoreCase("Job Seeker")) {

                System.out.println(
                        "ERROR: User is not a Job Seeker"
                );

                response.getWriter().print(
                        "invalid_role"
                );

                return;
            }


            // =====================================================
            // 6. GET JOB ID
            // =====================================================

            String jobIdStr =
                    request.getParameter("jobId");


            System.out.println(
                    "Job ID received = "
                    + jobIdStr
            );


            if (jobIdStr == null ||
                jobIdStr.trim().isEmpty()) {

                System.out.println(
                        "ERROR: Job ID is missing"
                );

                response.getWriter().print(
                        "jobId_missing"
                );

                return;
            }


            int jobId;


            try {

                jobId =
                        Integer.parseInt(
                                jobIdStr
                        );

            } catch (NumberFormatException e) {

                System.out.println(
                        "ERROR: Invalid Job ID = "
                        + jobIdStr
                );

                response.getWriter().print(
                        "invalid_jobId"
                );

                return;
            }


            System.out.println(
                    "Parsed Job ID = "
                    + jobId
            );


            // =====================================================
            // 7. GET RESUME
            // =====================================================

            String resume =
                    request.getParameter("resume");


            System.out.println(
                    "Resume received = "
                    + resume
            );


            if (resume == null ||
                resume.trim().isEmpty()) {

                System.out.println(
                        "ERROR: Resume is missing"
                );

                response.getWriter().print(
                        "resume_missing"
                );

                return;
            }


            // =====================================================
            // 8. CREATE APPLICATION OBJECT
            // =====================================================

            Application application =
                    new Application();


            application.setJobId(
                    jobId
            );


            // IMPORTANT:
            // Use the logged-in user's actual ID

            application.setSeekerId(
                    seekerId
            );


            application.setResume(
                    resume
            );


            System.out.println(
                    "================================="
            );

            System.out.println(
                    "APPLICATION DETAILS"
            );

            System.out.println(
                    "Job ID    = "
                    + application.getJobId()
            );

            System.out.println(
                    "Seeker ID = "
                    + application.getSeekerId()
            );

            System.out.println(
                    "Resume    = "
                    + application.getResume()
            );

            System.out.println(
                    "================================="
            );


            // =====================================================
            // 9. SAVE APPLICATION TO DATABASE
            // =====================================================

            ApplicationDAO dao =
                    new ApplicationDAO();


            boolean success =
                    dao.applyJob(
                            application
                    );


            // =====================================================
            // 10. SEND RESPONSE
            // =====================================================

            if (success) {

                System.out.println(
                        "---------------------------------"
                );

                System.out.println(
                        "APPLICATION INSERTED SUCCESSFULLY"
                );

                System.out.println(
                        "User ID = "
                        + seekerId
                );

                System.out.println(
                        "Job ID = "
                        + jobId
                );

                System.out.println(
                        "---------------------------------"
                );


                response.getWriter().print(
                        "success"
                );

            } else {

                System.out.println(
                        "---------------------------------"
                );

                System.out.println(
                        "APPLICATION INSERT FAILED"
                );

                System.out.println(
                        "---------------------------------"
                );


                response.getWriter().print(
                        "failed"
                );
            }


        } catch (Exception e) {

            System.out.println(
                    "================================="
            );

            System.out.println(
                    "       APPLY JOB ERROR"
            );

            System.out.println(
                    "================================="
            );


            e.printStackTrace();


            response.setStatus(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );


            response.getWriter().print(
                    "error"
            );
        }
    }
}