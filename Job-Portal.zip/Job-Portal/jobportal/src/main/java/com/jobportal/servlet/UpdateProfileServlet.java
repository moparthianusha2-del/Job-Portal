package com.jobportal.servlet;

import com.jobportal.dao.UserDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try {

            // Get logged-in user from session
            HttpSession session = request.getSession(false);

            if (session == null) {

                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

                response.getWriter().print(
                    "{\"success\":false,\"message\":\"Session expired.\"}"
                );

                return;
            }

            Object obj = session.getAttribute("loggedUser");

            if (obj == null) {

                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

                response.getWriter().print(
                    "{\"success\":false,\"message\":\"User not logged in.\"}"
                );

                return;
            }

            User loggedUser = (User) obj;

            int userId = loggedUser.getUserId();

            // Get updated values from profile.html
            String phone = request.getParameter("phone");
            String company = request.getParameter("company");

            if (phone == null) {
                phone = "";
            }

            if (company == null) {
                company = "";
            }

            // Update database
            UserDAO dao = new UserDAO();

            boolean success =
                    dao.updateProfile(userId, phone, company);

            if (success) {

                // Update session user object too
                loggedUser.setPhone(phone);
                loggedUser.setCompany(company);

                session.setAttribute("loggedUser", loggedUser);

                response.getWriter().print(
                    "{\"success\":true,\"message\":\"Profile updated successfully.\"}"
                );

            } else {

                response.getWriter().print(
                    "{\"success\":false,\"message\":\"Profile update failed.\"}"
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.setStatus(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Server error.\"}"
            );
        }
    }
}