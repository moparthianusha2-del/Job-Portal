package com.jobportal.dao;

import com.jobportal.db.DBConnection;
import com.jobportal.model.Job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class JobDAO {

    // =========================================================
    // GET ALL JOBS
    // =========================================================

    public List<Job> getAllJobs() {

        List<Job> jobs = new ArrayList<>();

        String sql =
                "SELECT * FROM JOBS " +
                "ORDER BY POSTED_DATE DESC";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Job job = new Job();

                job.setJobId(rs.getInt("JOB_ID"));
                job.setTitle(rs.getString("TITLE"));
                job.setDescription(rs.getString("DESCRIPTION"));
                job.setLocation(rs.getString("LOCATION"));
                job.setPostedDate(rs.getDate("POSTED_DATE"));
                job.setEmployerId(rs.getInt("EMPLOYER_ID"));

                jobs.add(job);
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET ALL JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return jobs;
    }


    // =========================================================
    // GET JOB BY ID
    // =========================================================

    public Job getJobById(int jobId) {

        Job job = null;

        String sql =
                "SELECT * FROM JOBS " +
                "WHERE JOB_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, jobId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    job = new Job();

                    job.setJobId(rs.getInt("JOB_ID"));
                    job.setTitle(rs.getString("TITLE"));
                    job.setDescription(rs.getString("DESCRIPTION"));
                    job.setLocation(rs.getString("LOCATION"));
                    job.setPostedDate(rs.getDate("POSTED_DATE"));
                    job.setEmployerId(rs.getInt("EMPLOYER_ID"));
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET JOB BY ID ERROR =========="
            );

            e.printStackTrace();
        }

        return job;
    }


    // =========================================================
    // POST NEW JOB
    // =========================================================

    public boolean postJob(
            String title,
            String description,
            String location,
            int employerId) {

        String sql =
                "INSERT INTO JOBS " +
                "(TITLE, DESCRIPTION, LOCATION, POSTED_DATE, EMPLOYER_ID) " +
                "VALUES (?, ?, ?, SYSDATE, ?)";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, location);
            ps.setInt(4, employerId);

            int rows = ps.executeUpdate();

            System.out.println(
                    "Rows inserted: " + rows
            );

            return rows > 0;

        } catch (Exception e) {

            System.out.println(
                    "========== POST JOB ERROR =========="
            );

            e.printStackTrace();

            return false;
        }
    }


    // =========================================================
    // GET JOBS POSTED BY PARTICULAR EMPLOYER
    // =========================================================

    public List<Job> getJobsByEmployer(int employerId) {

        List<Job> jobs = new ArrayList<>();

        String sql =
                "SELECT j.JOB_ID, " +
                "       j.TITLE, " +
                "       j.DESCRIPTION, " +
                "       j.LOCATION, " +
                "       j.POSTED_DATE, " +
                "       j.EMPLOYER_ID, " +
                "       (SELECT COUNT(*) " +
                "          FROM JOB_APPLICATIONS a " +
                "         WHERE a.JOB_ID = j.JOB_ID) " +
                "       AS APPLICATION_COUNT " +
                "FROM JOBS j " +
                "WHERE j.EMPLOYER_ID = ? " +
                "ORDER BY j.POSTED_DATE DESC";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Job job = new Job();

                    job.setJobId(
                            rs.getInt("JOB_ID")
                    );

                    job.setTitle(
                            rs.getString("TITLE")
                    );

                    job.setDescription(
                            rs.getString("DESCRIPTION")
                    );

                    job.setLocation(
                            rs.getString("LOCATION")
                    );

                    job.setPostedDate(
                            rs.getDate("POSTED_DATE")
                    );

                    job.setEmployerId(
                            rs.getInt("EMPLOYER_ID")
                    );

                    job.setApplicationCount(
                            rs.getInt("APPLICATION_COUNT")
                    );

                    jobs.add(job);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET EMPLOYER JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return jobs;
    }


    // =========================================================
    // GET TOTAL JOBS OF EMPLOYER
    // =========================================================

    public int getTotalJobs(int employerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOBS " +
                "WHERE EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET TOTAL JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // GET ACTIVE JOBS OF EMPLOYER
    //
    // Currently, every job posted by the employer is treated
    // as active because the JOBS table does not currently
    // contain a STATUS column.
    // =========================================================

    public int getActiveJobs(int employerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOBS " +
                "WHERE EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET ACTIVE JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // GET TOTAL APPLICATIONS FOR EMPLOYER
    // =========================================================

    public int getTotalApplications(int employerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOB_APPLICATIONS a " +
                "JOIN JOBS j " +
                "ON a.JOB_ID = j.JOB_ID " +
                "WHERE j.EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET TOTAL APPLICATIONS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // GET SHORTLISTED CANDIDATES
    // =========================================================

    public int getShortlistedCandidates(int employerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOB_APPLICATIONS a " +
                "JOIN JOBS j " +
                "ON a.JOB_ID = j.JOB_ID " +
                "WHERE j.EMPLOYER_ID = ? " +
                "AND UPPER(a.STATUS) = 'SHORTLISTED'";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET SHORTLISTED CANDIDATES ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // DELETE JOB
    // =========================================================

    public boolean deleteJob(
            int jobId,
            int employerId) {

        String sql =
                "DELETE FROM JOBS " +
                "WHERE JOB_ID = ? " +
                "AND EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, jobId);
            ps.setInt(2, employerId);

            int rows = ps.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            System.out.println(
                    "========== DELETE JOB ERROR =========="
            );

            e.printStackTrace();

            return false;
        }
    }


    // =========================================================
    // GET JOB FOR PARTICULAR EMPLOYER
    // =========================================================

    public Job getJobForEmployer(
            int jobId,
            int employerId) {

        Job job = null;

        String sql =
                "SELECT JOB_ID, " +
                "       TITLE, " +
                "       DESCRIPTION, " +
                "       LOCATION, " +
                "       POSTED_DATE, " +
                "       EMPLOYER_ID " +
                "FROM JOBS " +
                "WHERE JOB_ID = ? " +
                "AND EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, jobId);
            ps.setInt(2, employerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    job = new Job();

                    job.setJobId(
                            rs.getInt("JOB_ID")
                    );

                    job.setTitle(
                            rs.getString("TITLE")
                    );

                    job.setDescription(
                            rs.getString("DESCRIPTION")
                    );

                    job.setLocation(
                            rs.getString("LOCATION")
                    );

                    job.setPostedDate(
                            rs.getDate("POSTED_DATE")
                    );

                    job.setEmployerId(
                            rs.getInt("EMPLOYER_ID")
                    );
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== GET EMPLOYER JOB ERROR =========="
            );

            e.printStackTrace();
        }

        return job;
    }


    // =========================================================
    // UPDATE JOB
    // =========================================================

    public boolean updateJob(
            int jobId,
            int employerId,
            String title,
            String description,
            String location) {

        String sql =
                "UPDATE JOBS " +
                "SET TITLE = ?, " +
                "    DESCRIPTION = ?, " +
                "    LOCATION = ? " +
                "WHERE JOB_ID = ? " +
                "AND EMPLOYER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, location);
            ps.setInt(4, jobId);
            ps.setInt(5, employerId);

            int rows = ps.executeUpdate();

            System.out.println(
                    "Rows updated: " + rows
            );

            return rows > 0;

        } catch (Exception e) {

            System.out.println(
                    "========== UPDATE JOB ERROR =========="
            );

            e.printStackTrace();

            return false;
        }
    }

}