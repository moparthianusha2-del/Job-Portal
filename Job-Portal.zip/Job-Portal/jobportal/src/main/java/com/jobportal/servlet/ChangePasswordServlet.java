package com.jobportal.servlet;

import com.jobportal.dao.UserDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try {

            // Get session
            HttpSession session = request.getSession(false);

            if (session == null) {

                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

                response.getWriter().print(
                    "{\"success\":false,\"message\":\"Session expired.\"}"
                );

                return;
            }

            Object obj = session.getAttribute("loggedUser");

            if (obj == null) {

                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

                response.getWriter().print(
                    "{\"success\":false,\"message\":\"User not logged in.\"}"
                );

                return;
            }

            User loggedUser = (User) obj;

            int userId = loggedUser.getUserId();

            // Get password from frontend
            String newPassword =
                    request.getParameter("newPassword");

            if (newPassword == null ||
                newPassword.trim().isEmpty()) {

                response.getWriter().print(
                    "{\"success\":false,\"message\":\"Password cannot be empty.\"}"
                );

                return;
            }

            // Update password
            UserDAO dao = new UserDAO();

            boolean success =
                    dao.changePassword(userId, newPassword);

            if (success) {

                // Keep session object updated
                loggedUser.setPassword(newPassword);

                session.setAttribute("loggedUser", loggedUser);

                response.getWriter().print(
                    "{\"success\":true,\"message\":\"Password changed successfully.\"}"
                );

            } else {

                response.getWriter().print(
                    "{\"success\":false,\"message\":\"Password change failed.\"}"
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.setStatus(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Server error.\"}"
            );
        }
    }
}