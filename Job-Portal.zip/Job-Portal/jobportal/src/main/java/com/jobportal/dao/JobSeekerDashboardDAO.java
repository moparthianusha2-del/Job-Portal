package com.jobportal.dao;

import com.jobportal.db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JobSeekerDashboardDAO {

    // =========================================================
    // AVAILABLE JOBS
    // =========================================================

    public int getAvailableJobs() {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOBS";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {

            System.out.println(
                    "========== AVAILABLE JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // APPLIED JOBS
    // =========================================================

    public int getAppliedJobs(int seekerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOB_APPLICATIONS " +
                "WHERE SEEKER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, seekerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== APPLIED JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // SAVED JOBS
    // =========================================================

    public int getSavedJobs(int seekerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM SAVED_JOBS " +
                "WHERE USER_ID = ?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, seekerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== SAVED JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // INTERVIEW CALLS
    // =========================================================

    public int getInterviewCalls(int seekerId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM JOB_APPLICATIONS " +
                "WHERE SEEKER_ID = ? " +
                "AND UPPER(STATUS) LIKE '%INTERVIEW%'";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, seekerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== INTERVIEW CALLS ERROR =========="
            );

            e.printStackTrace();
        }

        return 0;
    }


    // =========================================================
    // LATEST JOBS
    // =========================================================

    public List<Map<String, Object>> getLatestJobs() {

        List<Map<String, Object>> jobs =
                new ArrayList<>();

        String sql =
                "SELECT * " +
                "FROM ( " +
                "    SELECT j.JOB_ID, " +
                "           j.TITLE, " +
                "           j.LOCATION, " +
                "           j.POSTED_DATE, " +
                "           NVL(u.COMPANY, u.NAME) AS COMPANY " +
                "    FROM JOBS j " +
                "    LEFT JOIN USERS u " +
                "        ON j.EMPLOYER_ID = u.USER_ID " +
                "    ORDER BY j.POSTED_DATE DESC " +
                ") " +
                "WHERE ROWNUM <= 5";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Map<String, Object> job =
                        new HashMap<>();

                job.put(
                        "jobId",
                        rs.getInt("JOB_ID")
                );

                job.put(
                        "title",
                        rs.getString("TITLE")
                );

                job.put(
                        "location",
                        rs.getString("LOCATION")
                );

                job.put(
                        "company",
                        rs.getString("COMPANY")
                );

                jobs.add(job);
            }

        } catch (Exception e) {

            System.out.println(
                    "========== LATEST JOBS ERROR =========="
            );

            e.printStackTrace();
        }

        return jobs;
    }


    // =========================================================
    // RECENT ACTIVITIES
    // =========================================================

    public List<Map<String, Object>> getRecentActivities(
            int seekerId) {

        List<Map<String, Object>> activities =
                new ArrayList<>();

        String sql =
                "SELECT * " +
                "FROM ( " +
                "    SELECT ACTIVITY_TYPE, " +
                "           TITLE, " +
                "           COMPANY, " +
                "           ACTIVITY_DATE, " +
                "           STATUS " +
                "    FROM ( " +
                "        SELECT " +
                "            'APPLIED' AS ACTIVITY_TYPE, " +
                "            j.TITLE AS TITLE, " +
                "            NVL(u.COMPANY, u.NAME) AS COMPANY, " +
                "            a.APPLY_DATE AS ACTIVITY_DATE, " +
                "            a.STATUS AS STATUS " +
                "        FROM JOB_APPLICATIONS a " +
                "        JOIN JOBS j " +
                "            ON a.JOB_ID = j.JOB_ID " +
                "        LEFT JOIN USERS u " +
                "            ON j.EMPLOYER_ID = u.USER_ID " +
                "        WHERE a.SEEKER_ID = ? " +

                "        UNION ALL " +

                "        SELECT " +
                "            'SAVED' AS ACTIVITY_TYPE, " +
                "            j.TITLE AS TITLE, " +
                "            NVL(u.COMPANY, u.NAME) AS COMPANY, " +
                "            s.SAVED_DATE AS ACTIVITY_DATE, " +
                "            'SAVED' AS STATUS " +
                "        FROM SAVED_JOBS s " +
                "        JOIN JOBS j " +
                "            ON s.JOB_ID = j.JOB_ID " +
                "        LEFT JOIN USERS u " +
                "            ON j.EMPLOYER_ID = u.USER_ID " +
                "        WHERE s.USER_ID = ? " +
                "    ) " +
                "    ORDER BY ACTIVITY_DATE DESC " +
                ") " +
                "WHERE ROWNUM <= 5";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, seekerId);
            ps.setInt(2, seekerId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Map<String, Object> activity =
                            new HashMap<>();

                    activity.put(
                            "activityType",
                            rs.getString("ACTIVITY_TYPE")
                    );

                    activity.put(
                            "title",
                            rs.getString("TITLE")
                    );

                    activity.put(
                            "company",
                            rs.getString("COMPANY")
                    );

                    activity.put(
                            "activityDate",
                            rs.getDate("ACTIVITY_DATE")
                    );

                    activity.put(
                            "status",
                            rs.getString("STATUS")
                    );

                    activities.add(activity);
                }
            }

        } catch (Exception e) {

            System.out.println(
                    "========== RECENT ACTIVITIES ERROR =========="
            );

            e.printStackTrace();
        }

        return activities;
    }
}