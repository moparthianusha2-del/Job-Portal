package com.jobportal.servlet;

import com.jobportal.dao.ApplicationDAO;
import com.jobportal.model.Application;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;

@WebServlet("/MyApplicationsServlet")
public class MyApplicationsServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        try {

            // =====================================================
            // 1. GET CURRENT SESSION
            // =====================================================

            HttpSession session =
                    request.getSession(false);

            if (session == null) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                    "{\"error\":\"User is not logged in\"}"
                );

                return;
            }


            // =====================================================
            // 2. GET LOGGED-IN USER
            // =====================================================

            Object loggedUserObject =
                    session.getAttribute("loggedUser");


            if (loggedUserObject == null) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                    "{\"error\":\"User session not found\"}"
                );

                return;
            }


            // =====================================================
            // 3. CHECK USER OBJECT
            // =====================================================

            if (!(loggedUserObject instanceof User)) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                    "{\"error\":\"Invalid user session\"}"
                );

                return;
            }


            User loggedUser =
                    (User) loggedUserObject;


            // =====================================================
            // 4. GET LOGGED-IN USER ID
            // =====================================================

            int seekerId =
                    loggedUser.getUserId();


            System.out.println(
                "======================================"
            );

            System.out.println(
                "MY APPLICATIONS REQUEST"
            );

            System.out.println(
                "Logged User ID = "
                + seekerId
            );

            System.out.println(
                "Logged User Name = "
                + loggedUser.getFullname()
            );

            System.out.println(
                "Logged User Email = "
                + loggedUser.getEmail()
            );

            System.out.println(
                "======================================"
            );


            // =====================================================
            // 5. GET APPLICATIONS FOR THIS USER ONLY
            // =====================================================

            ApplicationDAO dao =
                    new ApplicationDAO();


            List<Application> applications =
                    dao.getApplicationsBySeeker(
                            seekerId
                    );


            // =====================================================
            // 6. DATE FORMAT
            // =====================================================

            SimpleDateFormat dateFormat =
                    new SimpleDateFormat(
                            "yyyy-MM-dd"
                    );


            // =====================================================
            // 7. BUILD JSON
            // =====================================================

            out.print("[");


            for (
                int i = 0;
                i < applications.size();
                i++
            ) {

                Application application =
                        applications.get(i);


                out.print("{");


                // -------------------------------------------------
                // APP ID
                // -------------------------------------------------

                out.print(
                    "\"appId\":"
                    + application.getAppId()
                    + ","
                );


                // -------------------------------------------------
                // JOB ID
                // -------------------------------------------------

                out.print(
                    "\"jobId\":"
                    + application.getJobId()
                    + ","
                );


                // -------------------------------------------------
                // SEEKER ID
                // -------------------------------------------------

                out.print(
                    "\"seekerId\":"
                    + application.getSeekerId()
                    + ","
                );


                // -------------------------------------------------
                // RESUME
                // -------------------------------------------------

                out.print(
                    "\"resume\":\""
                    + escapeJson(
                        application.getResume()
                    )
                    + "\","
                );


                // -------------------------------------------------
                // APPLY DATE
                // -------------------------------------------------

                String applyDate = "";


                if (
                    application.getApplyDate()
                    != null
                ) {

                    applyDate =
                        dateFormat.format(
                            application.getApplyDate()
                        );
                }


                out.print(
                    "\"applyDate\":\""
                    + applyDate
                    + "\","
                );


                // -------------------------------------------------
                // JOB TITLE
                // -------------------------------------------------

                out.print(
                    "\"jobTitle\":\""
                    + escapeJson(
                        application.getJobTitle()
                    )
                    + "\","
                );


                // -------------------------------------------------
                // LOCATION
                // -------------------------------------------------

                out.print(
                    "\"location\":\""
                    + escapeJson(
                        application.getLocation()
                    )
                    + "\""
                );


                out.print("}");


                if (
                    i <
                    applications.size() - 1
                ) {

                    out.print(",");

                }

            }


            out.print("]");


        } catch (Exception e) {

            // =====================================================
            // ERROR HANDLING
            // =====================================================

            e.printStackTrace();


            response.setStatus(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );


            out.print(
                "{\"error\":\"Unable to load applications\"}"
            );
        }
    }


    // =========================================================
    // ESCAPE JSON SPECIAL CHARACTERS
    // =========================================================

    private String escapeJson(String value) {

        if (value == null) {

            return "";
        }


        return value

            .replace(
                "\\",
                "\\\\"
            )

            .replace(
                "\"",
                "\\\""
            )

            .replace(
                "\n",
                "\\n"
            )

            .replace(
                "\r",
                "\\r"
            );
    }
}