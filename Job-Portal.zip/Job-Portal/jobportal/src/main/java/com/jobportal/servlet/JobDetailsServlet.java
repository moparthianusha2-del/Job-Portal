package com.jobportal.servlet;

import com.jobportal.dao.JobDAO;
import com.jobportal.model.Job;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/JobDetailsServlet")
public class JobDetailsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String id = request.getParameter("id");

        if (id == null || id.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                    "Job ID is required");
            return;
        }

        int jobId;

        try {
            jobId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                    "Job ID must be a number");
            return;
        }

        JobDAO dao = new JobDAO();
        Job job = dao.getJobById(jobId);

        if (job == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND,
                    "Job not found");
            return;
        }

        PrintWriter out = response.getWriter();

        out.print("{");
        out.print("\"jobId\":" + job.getJobId() + ",");
        out.print("\"title\":\"" + escapeJson(job.getTitle()) + "\",");
        out.print("\"description\":\"" + escapeJson(job.getDescription()) + "\",");
        out.print("\"location\":\"" + escapeJson(job.getLocation()) + "\",");
        out.print("\"postedDate\":\""
                + escapeJson(String.valueOf(job.getPostedDate())) + "\",");
        out.print("\"employerId\":" + job.getEmployerId());
        out.print("}");
        out.flush();
    }

    private String escapeJson(String value) {
        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\t", "\\t");
    }
}