package com.jobportal.servlet;

import com.jobportal.dao.CompanyProfileDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/CompanyProfileServlet")
public class CompanyProfileServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        // =========================================
        // GET SESSION
        // =========================================

        HttpSession session =
                request.getSession(false);

        if (session == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            out.print(
                    "{\"success\":false," +
                    "\"message\":\"Session expired. Please login again.\"}"
            );

            return;
        }


        // =========================================
        // GET LOGGED-IN USER
        // =========================================

        Object obj =
                session.getAttribute("loggedUser");

        if (obj == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            out.print(
                    "{\"success\":false," +
                    "\"message\":\"Employer not logged in.\"}"
            );

            return;
        }


        User loggedUser = (User) obj;

        int employerId =
                loggedUser.getUserId();


        System.out.println(
                "Company Profile - Employer ID: "
                + employerId
        );


        // =========================================
        // GET COMPANY PROFILE
        // =========================================

        CompanyProfileDAO dao =
                new CompanyProfileDAO();

        User employer =
                dao.getCompanyProfile(employerId);


        if (employer == null) {

            response.setStatus(
                    HttpServletResponse.SC_NOT_FOUND
            );

            out.print(
                    "{\"success\":false," +
                    "\"message\":\"Company profile not found.\"}"
            );

            return;
        }


        // =========================================
        // CREATE JSON RESPONSE
        // =========================================

        StringBuilder json =
                new StringBuilder();

        json.append("{");

        json.append("\"success\":true,");

        json.append("\"userId\":");
        json.append(employer.getUserId());
        json.append(",");

        json.append("\"fullname\":\"");
        json.append(escapeJson(employer.getFullname()));
        json.append("\",");

        json.append("\"email\":\"");
        json.append(escapeJson(employer.getEmail()));
        json.append("\",");

        json.append("\"phone\":\"");
        json.append(escapeJson(employer.getPhone()));
        json.append("\",");

        json.append("\"role\":\"");
        json.append(escapeJson(employer.getRole()));
        json.append("\",");

        json.append("\"company\":\"");
        json.append(escapeJson(employer.getCompany()));
        json.append("\"");

        json.append("}");


        // =========================================
        // SEND JSON
        // =========================================

        out.print(json.toString());

        out.flush();
    }


    // =========================================
    // SAFE JSON ESCAPING
    // =========================================

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        StringBuilder result =
                new StringBuilder();

        for (int i = 0; i < value.length(); i++) {

            char c = value.charAt(i);

            switch (c) {

                case '"':
                    result.append("\\\"");
                    break;

                case '\\':
                    result.append("\\\\");
                    break;

                case '\b':
                    result.append("\\b");
                    break;

                case '\f':
                    result.append("\\f");
                    break;

                case '\n':
                    result.append("\\n");
                    break;

                case '\r':
                    result.append("\\r");
                    break;

                case '\t':
                    result.append("\\t");
                    break;

                default:

                    if (c < 0x20) {

                        result.append(
                                String.format(
                                        "\\u%04x",
                                        (int)c
                                )
                        );

                    } else {

                        result.append(c);
                    }

                    break;
            }
        }

        return result.toString();
    }
}