package com.jobportal.servlet;

import com.jobportal.dao.JobSeekerDashboardDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

@WebServlet("/JobSeekerDashboardServlet")
public class JobSeekerDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // =====================================================
        // GET SESSION
        // =====================================================

        HttpSession session =
                request.getSession(false);

        if (session == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter().print(
                    "{\"error\":\"Session expired. Please login again.\"}"
            );

            return;
        }


        // =====================================================
        // GET LOGGED USER
        // =====================================================

        Object obj =
                session.getAttribute("loggedUser");

        if (obj == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter().print(
                    "{\"error\":\"User not logged in.\"}"
            );

            return;
        }


        User loggedUser =
                (User) obj;

        int seekerId =
                loggedUser.getUserId();


        System.out.println(
                "===================================="
        );

        System.out.println(
                "JOB SEEKER DASHBOARD"
        );

        System.out.println(
                "Logged User ID = " + seekerId
        );

        System.out.println(
                "===================================="
        );


        // =====================================================
        // DAO
        // =====================================================

        JobSeekerDashboardDAO dao =
                new JobSeekerDashboardDAO();


        // =====================================================
        // COUNTS
        // =====================================================

        int availableJobs =
                dao.getAvailableJobs();

        int appliedJobs =
                dao.getAppliedJobs(seekerId);

        int savedJobs =
                dao.getSavedJobs(seekerId);

        int interviewCalls =
                dao.getInterviewCalls(seekerId);


        // =====================================================
        // LATEST JOBS
        // =====================================================

        List<Map<String, Object>> latestJobs =
                dao.getLatestJobs();


        // =====================================================
        // RECENT ACTIVITIES
        // =====================================================

        List<Map<String, Object>> recentActivities =
                dao.getRecentActivities(seekerId);


        // =====================================================
        // BUILD JSON
        // =====================================================

        PrintWriter out =
                response.getWriter();

        out.print("{");


        // =====================================================
        // COUNTS
        // =====================================================

        out.print("\"availableJobs\":");
        out.print(availableJobs);

        out.print(",");

        out.print("\"appliedJobs\":");
        out.print(appliedJobs);

        out.print(",");

        out.print("\"savedJobs\":");
        out.print(savedJobs);

        out.print(",");

        out.print("\"interviewCalls\":");
        out.print(interviewCalls);


        // =====================================================
        // LATEST JOBS
        // =====================================================

        out.print(",");

        out.print("\"latestJobs\":[");

        for (int i = 0;
             i < latestJobs.size();
             i++) {

            Map<String, Object> job =
                    latestJobs.get(i);

            if (i > 0) {
                out.print(",");
            }

            out.print("{");

            out.print("\"jobId\":");
            out.print(
                    job.get("jobId")
            );

            out.print(",");

            out.print("\"title\":\"");
            out.print(
                    escapeJson(
                            String.valueOf(
                                    job.get("title")
                            )
                    )
            );
            out.print("\"");

            out.print(",");

            out.print("\"company\":\"");
            out.print(
                    escapeJson(
                            job.get("company") == null
                                    ? ""
                                    : String.valueOf(
                                            job.get("company")
                                    )
                    )
            );
            out.print("\"");

            out.print(",");

            out.print("\"location\":\"");
            out.print(
                    escapeJson(
                            job.get("location") == null
                                    ? ""
                                    : String.valueOf(
                                            job.get("location")
                                    )
                    )
            );
            out.print("\"");

            out.print("}");
        }

        out.print("]");


        // =====================================================
        // RECENT ACTIVITIES
        // =====================================================

        out.print(",");

        out.print("\"recentActivities\":[");

        for (int i = 0;
             i < recentActivities.size();
             i++) {

            Map<String, Object> activity =
                    recentActivities.get(i);

            if (i > 0) {
                out.print(",");
            }

            out.print("{");

            out.print("\"activityType\":\"");

            out.print(
                    escapeJson(
                            String.valueOf(
                                    activity.get(
                                            "activityType"
                                    )
                            )
                    )
            );

            out.print("\"");

            out.print(",");

            out.print("\"title\":\"");

            out.print(
                    escapeJson(
                            String.valueOf(
                                    activity.get("title")
                            )
                    )
            );

            out.print("\"");

            out.print(",");

            out.print("\"company\":\"");

            out.print(
                    escapeJson(
                            activity.get("company") == null
                                    ? ""
                                    : String.valueOf(
                                            activity.get("company")
                                    )
                    )
            );

            out.print("\"");

            out.print(",");

            out.print("\"status\":\"");

            out.print(
                    escapeJson(
                            activity.get("status") == null
                                    ? ""
                                    : String.valueOf(
                                            activity.get("status")
                                    )
                    )
            );

            out.print("\"");

            out.print("}");
        }

        out.print("]");


        // =====================================================
        // END JSON
        // =====================================================

        out.print("}");
    }


    // =========================================================
    // JSON ESCAPE
    // =========================================================

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}