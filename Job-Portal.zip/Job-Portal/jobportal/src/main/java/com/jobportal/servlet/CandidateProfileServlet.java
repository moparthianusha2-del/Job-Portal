package com.jobportal.servlet;

import com.jobportal.dao.CandidateProfileDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/CandidateProfileServlet")
public class CandidateProfileServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // =====================================================
        // GET SEEKER ID
        // =====================================================

        String seekerIdParam =
                request.getParameter("seekerId");

        if (seekerIdParam == null ||
            seekerIdParam.trim().isEmpty()) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"Candidate ID is missing.\"}"
            );

            return;
        }

        int seekerId;

        try {

            seekerId =
                    Integer.parseInt(seekerIdParam);

        } catch (NumberFormatException e) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"Invalid candidate ID.\"}"
            );

            return;
        }

        // =====================================================
        // GET CANDIDATE
        // =====================================================

        CandidateProfileDAO dao =
                new CandidateProfileDAO();

        User candidate =
                dao.getCandidateProfile(seekerId);

        if (candidate == null) {

            response.setStatus(
                    HttpServletResponse.SC_NOT_FOUND
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"Candidate not found.\"}"
            );

            return;
        }

        // =====================================================
        // SEND JSON
        // =====================================================

        PrintWriter out =
                response.getWriter();

        out.print("{");

        out.print("\"success\":true,");

        out.print("\"userId\":" +
                candidate.getUserId() + ",");

        out.print("\"fullname\":\"" +
                escapeJson(candidate.getFullname()) + "\",");

        out.print("\"email\":\"" +
                escapeJson(candidate.getEmail()) + "\",");

        out.print("\"phone\":\"" +
                escapeJson(candidate.getPhone()) + "\",");

        out.print("\"role\":\"" +
                escapeJson(candidate.getRole()) + "\",");

        out.print("\"company\":\"" +
                escapeJson(candidate.getCompany()) +
                "\"");

        out.print("}");
    }


    // =========================================================
    // ESCAPE JSON
    // =========================================================

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }
}