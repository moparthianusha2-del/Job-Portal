package com.jobportal.servlet;

import com.jobportal.dao.UserDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/EmployerProfileServlet")
public class EmployerProfileServlet extends HttpServlet {

    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }


    // =========================================================
    // GET - LOAD LOGGED-IN EMPLOYER PROFILE
    // =========================================================

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        try {

            // =================================================
            // GET EXISTING LOGIN SESSION
            // =================================================

            HttpSession session =
                    request.getSession(false);

            if (session == null) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                        "{\"success\":false,\"message\":\"Session expired. Please login again.\"}"
                );

                return;
            }


            // =================================================
            // GET LOGGED-IN USER
            //
            // LoginServlet stores:
            // session.setAttribute("loggedUser", user);
            // =================================================

            Object obj =
                    session.getAttribute("loggedUser");

            if (obj == null) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                        "{\"success\":false,\"message\":\"User is not logged in.\"}"
                );

                return;
            }


            // =================================================
            // CONVERT SESSION OBJECT TO USER
            // =================================================

            if (!(obj instanceof User)) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                        "{\"success\":false,\"message\":\"Invalid login session.\"}"
                );

                return;
            }

            User loggedUser =
                    (User) obj;


            // =================================================
            // GET USER ID
            // =================================================

            int userId =
                    loggedUser.getUserId();


            System.out.println(
                    "========== EMPLOYER PROFILE =========="
            );

            System.out.println(
                    "Employer ID : " + userId
            );

            System.out.println(
                    "Employer Name : "
                    + loggedUser.getFullname()
            );

            System.out.println(
                    "Employer Email : "
                    + loggedUser.getEmail()
            );

            System.out.println(
                    "Employer Role : "
                    + loggedUser.getRole()
            );


            // =================================================
            // CHECK EMPLOYER ROLE
            // =================================================

            if (loggedUser.getRole() == null ||
                !loggedUser.getRole()
                        .equalsIgnoreCase("EMPLOYER")) {

                response.setStatus(
                        HttpServletResponse.SC_FORBIDDEN
                );

                out.print(
                        "{\"success\":false,\"message\":\"Access denied. Employer account required.\"}"
                );

                return;
            }


            // =================================================
            // GET LATEST USER DATA FROM DATABASE
            // =================================================

            User user =
                    userDAO.getUserById(userId);


            if (user == null) {

                response.setStatus(
                        HttpServletResponse.SC_NOT_FOUND
                );

                out.print(
                        "{\"success\":false,\"message\":\"Employer profile not found.\"}"
                );

                return;
            }


            // =================================================
            // SEND EMPLOYER PROFILE JSON
            // =================================================

            out.print("{");

            out.print(
                    "\"success\":true,"
            );

            out.print(
                    "\"userId\":"
                    + user.getUserId()
                    + ","
            );

            out.print(
                    "\"fullname\":\""
                    + escapeJson(user.getFullname())
                    + "\","
            );

            out.print(
                    "\"email\":\""
                    + escapeJson(user.getEmail())
                    + "\","
            );

            out.print(
                    "\"phone\":\""
                    + escapeJson(user.getPhone())
                    + "\","
            );

            out.print(
                    "\"role\":\""
                    + escapeJson(user.getRole())
                    + "\","
            );

            out.print(
                    "\"company\":\""
                    + escapeJson(user.getCompany())
                    + "\""
            );

            out.print("}");


        } catch (Exception e) {

            System.out.println(
                    "========== EMPLOYER PROFILE ERROR =========="
            );

            e.printStackTrace();

            response.setStatus(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            out.print(
                    "{\"success\":false,\"message\":\"Unable to load employer profile.\"}"
            );
        }
    }


    // =========================================================
    // POST - UPDATE EMPLOYER PROFILE
    // =========================================================

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        try {

            // =================================================
            // GET EXISTING SESSION
            // =================================================

            HttpSession session =
                    request.getSession(false);

            if (session == null) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                        "{\"success\":false,\"message\":\"Session expired. Please login again.\"}"
                );

                return;
            }


            // =================================================
            // GET LOGGED-IN USER
            // =================================================

            Object obj =
                    session.getAttribute("loggedUser");

            if (obj == null) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                        "{\"success\":false,\"message\":\"User is not logged in.\"}"
                );

                return;
            }


            if (!(obj instanceof User)) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                        "{\"success\":false,\"message\":\"Invalid login session.\"}"
                );

                return;
            }


            User loggedUser =
                    (User) obj;


            // =================================================
            // CHECK EMPLOYER ROLE
            // =================================================

            if (loggedUser.getRole() == null ||
                !loggedUser.getRole()
                        .equalsIgnoreCase("EMPLOYER")) {

                response.setStatus(
                        HttpServletResponse.SC_FORBIDDEN
                );

                out.print(
                        "{\"success\":false,\"message\":\"Access denied. Employer account required.\"}"
                );

                return;
            }


            // =================================================
            // GET EMPLOYER ID
            // =================================================

            int userId =
                    loggedUser.getUserId();


            // =================================================
            // GET FORM DATA
            // =================================================

            String fullname =
                    request.getParameter("fullname");

            String email =
                    request.getParameter("email");

            String phone =
                    request.getParameter("phone");

            String company =
                    request.getParameter("company");


            // =================================================
            // VALIDATION
            // =================================================

            if (fullname == null ||
                fullname.trim().isEmpty()) {

                out.print(
                        "{\"success\":false,\"message\":\"Full name is required.\"}"
                );

                return;
            }


            if (email == null ||
                email.trim().isEmpty()) {

                out.print(
                        "{\"success\":false,\"message\":\"Email is required.\"}"
                );

                return;
            }


            // =================================================
            // UPDATE DATABASE
            // =================================================

            boolean updated =
                    userDAO.updateEmployerProfile(
                            userId,
                            fullname.trim(),
                            email.trim(),
                            phone != null
                                    ? phone.trim()
                                    : "",
                            company != null
                                    ? company.trim()
                                    : ""
                    );


            // =================================================
            // UPDATE SESSION USER
            // =================================================

            if (updated) {

                loggedUser.setFullname(
                        fullname.trim()
                );

                loggedUser.setEmail(
                        email.trim()
                );

                loggedUser.setPhone(
                        phone != null
                                ? phone.trim()
                                : ""
                );

                loggedUser.setCompany(
                        company != null
                                ? company.trim()
                                : ""
                );

                session.setAttribute(
                        "loggedUser",
                        loggedUser
                );


                out.print(
                        "{\"success\":true,\"message\":\"Employer profile updated successfully.\"}"
                );

            } else {

                out.print(
                        "{\"success\":false,\"message\":\"Profile update failed.\"}"
                );
            }


        } catch (Exception e) {

            System.out.println(
                    "========== EMPLOYER PROFILE UPDATE ERROR =========="
            );

            e.printStackTrace();

            response.setStatus(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            out.print(
                    "{\"success\":false,\"message\":\"Unable to update employer profile.\"}"
            );
        }
    }


    // =========================================================
    // ESCAPE JSON
    // =========================================================

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}