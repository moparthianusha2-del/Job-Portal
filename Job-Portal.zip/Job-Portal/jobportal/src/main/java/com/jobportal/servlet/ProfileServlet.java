package com.jobportal.servlet;

import com.jobportal.dao.UserDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");

        HttpSession session = request.getSession(false);

       if (session == null) {

            System.out.println("Session is NULL");

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;

        }

        System.out.println("Session ID: " + session.getId());

        Object obj = session.getAttribute("loggedUser");

        if (obj == null) {

            System.out.println("loggedUser is NULL");

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;

        }

        User loggedUser = (User) session.getAttribute("loggedUser");

        UserDAO dao = new UserDAO();

        User user = dao.getUserById(loggedUser.getUserId());

        PrintWriter out = response.getWriter();

        out.print("{");
        out.print("\"userId\":" + user.getUserId() + ",");
        out.print("\"fullname\":\"" + user.getFullname() + "\",");
        out.print("\"email\":\"" + user.getEmail() + "\",");
        out.print("\"phone\":\"" + user.getPhone() + "\",");
        out.print("\"role\":\"" + user.getRole() + "\",");
        out.print("\"company\":\"" +
        (user.getCompany() == null ? "" : user.getCompany()) +
        "\"");
        out.print("}");

    }

}