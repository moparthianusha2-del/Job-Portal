package com.jobportal.servlet;

import com.jobportal.dao.ApplicationDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/UpdateApplicationStatusServlet")
public class UpdateApplicationStatusServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // =========================================
        // GET SESSION
        // =========================================

        HttpSession session =
                request.getSession(false);

        if (session == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"Session expired.\"}"
            );

            return;
        }

        Object obj =
                session.getAttribute("loggedUser");

        if (obj == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"User not logged in.\"}"
            );

            return;
        }

        User loggedUser = (User) obj;

        int employerId =
                loggedUser.getUserId();

        // =========================================
        // GET PARAMETERS
        // =========================================

        String appIdParam =
                request.getParameter("appId");

        String status =
                request.getParameter("status");

        if (appIdParam == null || status == null) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"Missing parameters.\"}"
            );

            return;
        }

        int appId;

        try {

            appId =
                    Integer.parseInt(appIdParam);

        } catch (NumberFormatException e) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"Invalid application ID.\"}"
            );

            return;
        }

        // =========================================
        // ALLOWED STATUS VALUES
        // =========================================

        if (!status.equals("SHORTLISTED")
                && !status.equals("REJECTED")) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"Invalid status.\"}"
            );

            return;
        }

        // =========================================
        // UPDATE DATABASE
        // =========================================

        ApplicationDAO dao =
                new ApplicationDAO();

        boolean success =
                dao.updateApplicationStatus(
                        appId,
                        status,
                        employerId
                );

        // =========================================
        // RESPONSE
        // =========================================

        if (success) {

            System.out.println(
                    "Application " + appId +
                    " updated to " + status +
                    " by Employer " + employerId
            );

            response.getWriter().print(
                    "{\"success\":true,\"message\":\"Application status updated successfully.\"}"
            );

        } else {

            response.setStatus(
                    HttpServletResponse.SC_NOT_FOUND
            );

            response.getWriter().print(
                    "{\"success\":false,\"message\":\"Application not found or access denied.\"}"
            );
        }
    }
}