package com.jobportal.servlet;

import com.jobportal.dao.JobDAO;
import com.jobportal.model.Job;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/SearchJobsServlet")
public class SearchJobsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        System.out.println("====================================");
        System.out.println("SearchJobsServlet called");
        System.out.println("====================================");

        JobDAO dao = new JobDAO();

        List<Job> jobs = dao.getAllJobs();

        System.out.println(
                "Jobs received from DAO: " + jobs.size()
        );

        PrintWriter out = response.getWriter();

        out.print("[");

        for (int i = 0; i < jobs.size(); i++) {

            Job job = jobs.get(i);

            out.print("{");

            out.print("\"jobId\":"
                    + job.getJobId()
                    + ",");

            out.print("\"title\":\""
                    + escapeJson(job.getTitle())
                    + "\",");

            out.print("\"description\":\""
                    + escapeJson(job.getDescription())
                    + "\",");

            out.print("\"location\":\""
                    + escapeJson(job.getLocation())
                    + "\",");

            out.print("\"postedDate\":\""
                    + escapeJson(
                            String.valueOf(
                                    job.getPostedDate()
                            )
                    )
                    + "\",");

            out.print("\"employerId\":"
                    + job.getEmployerId());

            out.print("}");

            if (i < jobs.size() - 1) {

                out.print(",");

            }
        }

        out.print("]");

        out.flush();

        System.out.println(
                "SearchJobsServlet response sent successfully."
        );
    }


    // =========================================================
    // ESCAPE SPECIAL CHARACTERS FOR JSON
    // =========================================================

    private String escapeJson(String value) {

        if (value == null) {

            return "";

        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\t", "\\t");
    }
}