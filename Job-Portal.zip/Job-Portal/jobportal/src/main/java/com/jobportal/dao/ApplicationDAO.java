package com.jobportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.jobportal.db.DBConnection;
import com.jobportal.model.Application;

public class ApplicationDAO {

    // =========================================================
    // APPLY FOR JOB
    // =========================================================

    public boolean applyJob(Application application) {

        boolean success = false;

        String sql =
            "INSERT INTO JOB_APPLICATIONS " +
            "(APP_ID, JOB_ID, SEEKER_ID, RESUME, APPLY_DATE) " +
            "VALUES " +
            "(JOB_APPLICATIONS_SEQ.NEXTVAL, ?, ?, ?, SYSDATE)";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, application.getJobId());
            ps.setInt(2, application.getSeekerId());
            ps.setString(3, application.getResume());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                success = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return success;
    }


    // =========================================================
    // GET APPLICATIONS BY SEEKER
    // =========================================================

    public List<Application> getApplicationsBySeeker(int seekerId) {

        List<Application> applications = new ArrayList<>();

        String sql =
            "SELECT a.APP_ID, " +
            "       a.JOB_ID, " +
            "       a.SEEKER_ID, " +
            "       a.RESUME, " +
            "       a.APPLY_DATE, " +
            "       j.TITLE, " +
            "       j.LOCATION " +
            "FROM JOB_APPLICATIONS a " +
            "JOIN JOBS j " +
            "ON a.JOB_ID = j.JOB_ID " +
            "WHERE a.SEEKER_ID = ? " +
            "ORDER BY a.APPLY_DATE DESC";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, seekerId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Application application = new Application();

                application.setAppId(
                    rs.getInt("APP_ID")
                );

                application.setJobId(
                    rs.getInt("JOB_ID")
                );

                application.setSeekerId(
                    rs.getInt("SEEKER_ID")
                );

                application.setResume(
                    rs.getString("RESUME")
                );

                application.setApplyDate(
                    rs.getDate("APPLY_DATE")
                );

                application.setJobTitle(
                    rs.getString("TITLE")
                );

                application.setLocation(
                    rs.getString("LOCATION")
                );

                applications.add(application);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return applications;
    }

    // =========================================================
// UPDATE APPLICATION STATUS
// =========================================================

public boolean updateStatus(int appId, String status) {

    String sql =
        "UPDATE JOB_APPLICATIONS " +
        "SET STATUS = ? " +
        "WHERE APP_ID = ?";

    try (
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(sql)
    ) {

        ps.setString(1, status);
        ps.setInt(2, appId);

        int rowsUpdated = ps.executeUpdate();

        return rowsUpdated > 0;

    } catch (Exception e) {

        e.printStackTrace();

    }

    return false;
}

// =========================================================
// UPDATE APPLICATION STATUS
// =========================================================

public boolean updateApplicationStatus(
        int appId,
        String status,
        int employerId) {

    String sql =
        "UPDATE JOB_APPLICATIONS A " +
        "SET A.STATUS = ? " +
        "WHERE A.APP_ID = ? " +
        "AND EXISTS ( " +
        "    SELECT 1 " +
        "    FROM JOBS J " +
        "    WHERE J.JOB_ID = A.JOB_ID " +
        "    AND J.EMPLOYER_ID = ? " +
        ")";

    try (
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(sql)
    ) {

        ps.setString(1, status);
        ps.setInt(2, appId);
        ps.setInt(3, employerId);

        return ps.executeUpdate() > 0;

    } catch (Exception e) {

        e.printStackTrace();

        return false;
    }
}

}