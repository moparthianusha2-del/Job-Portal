package com.jobportal.model;

import java.sql.Date;

public class Job {

    // =========================================================
    // FIELDS
    // =========================================================

    private int jobId;
    private String title;
    private String description;
    private String location;
    private Date postedDate;
    private int employerId;

    // Number of applications received for this job
    private int applicationCount;


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public Job() {
    }


    // =========================================================
    // JOB ID
    // =========================================================

    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }


    // =========================================================
    // TITLE
    // =========================================================

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    // =========================================================
    // DESCRIPTION
    // =========================================================

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    // =========================================================
    // LOCATION
    // =========================================================

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    // =========================================================
    // POSTED DATE
    // =========================================================

    public Date getPostedDate() {
        return postedDate;
    }

    public void setPostedDate(Date postedDate) {
        this.postedDate = postedDate;
    }


    // =========================================================
    // EMPLOYER ID
    // =========================================================

    public int getEmployerId() {
        return employerId;
    }

    public void setEmployerId(int employerId) {
        this.employerId = employerId;
    }


    // =========================================================
    // APPLICATION COUNT
    // =========================================================

    public int getApplicationCount() {
        return applicationCount;
    }

    public void setApplicationCount(int applicationCount) {
        this.applicationCount = applicationCount;
    }

}