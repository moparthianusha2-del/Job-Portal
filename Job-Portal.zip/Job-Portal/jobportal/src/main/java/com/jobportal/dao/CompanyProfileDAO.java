package com.jobportal.dao;

import com.jobportal.db.DBConnection;
import com.jobportal.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CompanyProfileDAO {

    // =========================================================
    // GET COMPANY PROFILE
    // =========================================================

    public User getCompanyProfile(int employerId) {

        User employer = null;

        String sql =
                "SELECT USER_ID, NAME, EMAIL, PHONE, ROLE, COMPANY " +
                "FROM USERS " +
                "WHERE USER_ID = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                employer = new User();

                employer.setUserId(
                        rs.getInt("USER_ID")
                );

                employer.setFullname(
                        rs.getString("NAME")
                );

                employer.setEmail(
                        rs.getString("EMAIL")
                );

                employer.setPhone(
                        rs.getString("PHONE")
                );

                employer.setRole(
                        rs.getString("ROLE")
                );

                employer.setCompany(
                        rs.getString("COMPANY")
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return employer;
    }
}