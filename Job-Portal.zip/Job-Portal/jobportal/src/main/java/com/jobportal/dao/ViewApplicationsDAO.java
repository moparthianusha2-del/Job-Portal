package com.jobportal.dao;

import com.jobportal.db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ViewApplicationsDAO {

    // =========================================================
    // GET APPLICATIONS FOR AN EMPLOYER
    // =========================================================

    public List<ApplicationData> getApplications(int employerId) {

        List<ApplicationData> applications = new ArrayList<>();

        String sql =
                "SELECT " +
                "A.APP_ID, " +
                "A.SEEKER_ID, " +
                "U.NAME AS CANDIDATE, " +
                "U.EMAIL, " +
                "J.TITLE AS JOB_TITLE, " +
                "A.RESUME, " +
                "A.APPLY_DATE, " +
                "A.STATUS " +
                "FROM JOB_APPLICATIONS A " +
                "JOIN USERS U " +
                "ON A.SEEKER_ID = U.USER_ID " +
                "JOIN JOBS J " +
                "ON A.JOB_ID = J.JOB_ID " +
                "WHERE J.EMPLOYER_ID = ? " +
                "ORDER BY A.APPLY_DATE DESC";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, employerId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                ApplicationData application =
                        new ApplicationData();

                application.setAppId(
                        rs.getInt("APP_ID")
                );

                application.setSeekerId(
                        rs.getInt("SEEKER_ID")
                );

                application.setCandidate(
                        rs.getString("CANDIDATE")
                );

                application.setEmail(
                        rs.getString("EMAIL")
                );

                application.setJobTitle(
                        rs.getString("JOB_TITLE")
                );

                application.setResume(
                        rs.getString("RESUME")
                );

                application.setApplyDate(
                        rs.getDate("APPLY_DATE")
                );

                application.setStatus(
                        rs.getString("STATUS")
                );

                applications.add(application);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return applications;
    }


    // =========================================================
    // APPLICATION DATA MODEL
    // =========================================================

    public static class ApplicationData {

        private int appId;
        private int seekerId;
        private String candidate;
        private String email;
        private String jobTitle;
        private String resume;
        private java.sql.Date applyDate;
        private String status;


        // =====================================================
        // APP ID
        // =====================================================

        public int getAppId() {
            return appId;
        }

        public void setAppId(int appId) {
            this.appId = appId;
        }


        // =====================================================
        // SEEKER ID
        // =====================================================

        public int getSeekerId() {
            return seekerId;
        }

        public void setSeekerId(int seekerId) {
            this.seekerId = seekerId;
        }


        // =====================================================
        // CANDIDATE
        // =====================================================

        public String getCandidate() {
            return candidate;
        }

        public void setCandidate(String candidate) {
            this.candidate = candidate;
        }


        // =====================================================
        // EMAIL
        // =====================================================

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }


        // =====================================================
        // JOB TITLE
        // =====================================================

        public String getJobTitle() {
            return jobTitle;
        }

        public void setJobTitle(String jobTitle) {
            this.jobTitle = jobTitle;
        }


        // =====================================================
        // RESUME
        // =====================================================

        public String getResume() {
            return resume;
        }

        public void setResume(String resume) {
            this.resume = resume;
        }


        // =====================================================
        // APPLY DATE
        // =====================================================

        public java.sql.Date getApplyDate() {
            return applyDate;
        }

        public void setApplyDate(java.sql.Date applyDate) {
            this.applyDate = applyDate;
        }


        // =====================================================
        // STATUS
        // =====================================================

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
}