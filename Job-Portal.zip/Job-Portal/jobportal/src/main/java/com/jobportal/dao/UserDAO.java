package com.jobportal.dao;

import com.jobportal.db.DBConnection;
import com.jobportal.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

    // =========================================================
    // REGISTER USER
    // =========================================================

    public boolean registerUser(User user) {

        boolean status = false;

        String sql =
            "INSERT INTO USERS " +
            "(NAME, EMAIL, PASSWORD, ROLE, PHONE, COMPANY) " +
            "VALUES (?, ?, ?, ?, ?, ?)";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, user.getFullname());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.setString(5, user.getPhone());
            ps.setString(6, user.getCompany());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                status = true;
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return status;
    }


    // =========================================================
    // LOGIN USER
    // =========================================================

    public User login(
            String email,
            String password,
            String role) {

        User user = null;

        String sql =
            "SELECT * FROM USERS " +
            "WHERE EMAIL = ? " +
            "AND PASSWORD = ? " +
            "AND ROLE = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, email);
            ps.setString(2, password);
            ps.setString(3, role);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    user = new User();

                    user.setUserId(
                        rs.getInt("USER_ID")
                    );

                    user.setFullname(
                        rs.getString("NAME")
                    );

                    user.setEmail(
                        rs.getString("EMAIL")
                    );

                    user.setPassword(
                        rs.getString("PASSWORD")
                    );

                    user.setPhone(
                        rs.getString("PHONE")
                    );

                    user.setRole(
                        rs.getString("ROLE")
                    );

                    user.setCompany(
                        rs.getString("COMPANY")
                    );
                }
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return user;
    }


    // =========================================================
    // GET USER BY ID
    // =========================================================

    public User getUserById(int userId) {

        User user = null;

        String sql =
            "SELECT * FROM USERS " +
            "WHERE USER_ID = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    user = new User();

                    user.setUserId(
                        rs.getInt("USER_ID")
                    );

                    user.setFullname(
                        rs.getString("NAME")
                    );

                    user.setEmail(
                        rs.getString("EMAIL")
                    );

                    user.setPassword(
                        rs.getString("PASSWORD")
                    );

                    user.setPhone(
                        rs.getString("PHONE")
                    );

                    user.setRole(
                        rs.getString("ROLE")
                    );

                    user.setCompany(
                        rs.getString("COMPANY")
                    );
                }
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return user;
    }


    // =========================================================
    // UPDATE BASIC PROFILE
    // =========================================================
    //
    // This method is kept from your original UserDAO.
    //
    // It updates:
    // PHONE
    // COMPANY
    //
    // =========================================================

    public boolean updateProfile(
            int userId,
            String phone,
            String company) {

        String sql =
            "UPDATE USERS " +
            "SET PHONE = ?, COMPANY = ? " +
            "WHERE USER_ID = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, phone);
            ps.setString(2, company);
            ps.setInt(3, userId);

            int rows = ps.executeUpdate();

            return rows > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // =========================================================
    // UPDATE EMPLOYER PROFILE
    // =========================================================
    //
    // Used by:
    // EmployerProfileServlet
    //
    // Updates the logged-in employer's:
    //
    // NAME
    // EMAIL
    // PHONE
    // COMPANY
    //
    // =========================================================

    public boolean updateEmployerProfile(
            int userId,
            String fullname,
            String email,
            String phone,
            String company) {

        String sql =
            "UPDATE USERS " +
            "SET NAME = ?, " +
            "EMAIL = ?, " +
            "PHONE = ?, " +
            "COMPANY = ? " +
            "WHERE USER_ID = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, fullname);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setString(4, company);
            ps.setInt(5, userId);

            int rows = ps.executeUpdate();

            return rows > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // =========================================================
    // CHANGE PASSWORD
    // =========================================================

    public boolean changePassword(
            int userId,
            String newPassword) {

        String sql =
            "UPDATE USERS " +
            "SET PASSWORD = ? " +
            "WHERE USER_ID = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, newPassword);
            ps.setInt(2, userId);

            int rows = ps.executeUpdate();

            return rows > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }
}