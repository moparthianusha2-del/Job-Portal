package com.jobportal.servlet;

import com.jobportal.dao.JobDAO;
import com.jobportal.model.Job;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/ManageJobsServlet")
public class ManageJobsServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType(
                "application/json"
        );

        response.setCharacterEncoding(
                "UTF-8"
        );


        // =========================================
        // GET EXISTING SESSION
        // =========================================

        HttpSession session =
                request.getSession(false);


        // =========================================
        // SESSION DOES NOT EXIST
        // =========================================

        if (session == null) {

            System.out.println(
                    "Manage Jobs: NO SESSION FOUND"
            );

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter().print(
                    "{\"success\":false," +
                    "\"message\":\"Session expired. Please login again.\"}"
            );

            return;
        }


        // =========================================
        // DEBUG SESSION
        // =========================================

        System.out.println(
                "========== MANAGE JOBS =========="
        );

        System.out.println(
                "Session ID : " +
                session.getId()
        );


        // =========================================
        // GET USER ID FROM SESSION
        // =========================================

        Object userIdObject =
                session.getAttribute("userId");


        int employerId = 0;


        // =========================================
        // METHOD 1:
        // USER ID STORED DIRECTLY
        // =========================================

        if (userIdObject != null) {

            try {

                employerId =
                        Integer.parseInt(
                                userIdObject.toString()
                        );

            }

            catch (NumberFormatException e) {

                System.out.println(
                        "Invalid userId in session."
                );

            }
        }


        // =========================================
        // METHOD 2:
        // FALLBACK TO loggedUser
        // =========================================

        if (employerId == 0) {

            Object loggedUserObject =
                    session.getAttribute(
                            "loggedUser"
                    );


            if (
                loggedUserObject instanceof User
            ) {

                User loggedUser =
                        (User) loggedUserObject;


                employerId =
                        loggedUser.getUserId();
            }
        }


        // =========================================
        // NO USER ID FOUND
        // =========================================

        if (employerId == 0) {

            System.out.println(
                    "Manage Jobs: USER ID NOT FOUND"
            );

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            response.getWriter().print(
                    "{\"success\":false," +
                    "\"message\":\"User session not found. Please login again.\"}"
            );

            return;
        }


        // =========================================
        // DEBUG
        // =========================================

        System.out.println(
                "Employer ID : " +
                employerId
        );


        // =========================================
        // DAO
        // =========================================

        JobDAO dao =
                new JobDAO();


        List<Job> jobs =
                dao.getJobsByEmployer(
                        employerId
                );


        int totalJobs =
                dao.getTotalJobs(
                        employerId
                );


        int totalApplications =
                dao.getTotalApplications(
                        employerId
                );


        // =========================================
        // CURRENT STATUS LOGIC
        // =========================================

        int activeJobs =
                totalJobs;

        int closedJobs =
                0;


        // =========================================
        // JSON RESPONSE
        // =========================================

        PrintWriter out =
                response.getWriter();


        out.print("{");

        out.print(
                "\"success\":true,"
        );


        out.print(
                "\"totalJobs\":" +
                totalJobs +
                ","
        );


        out.print(
                "\"activeJobs\":" +
                activeJobs +
                ","
        );


        out.print(
                "\"closedJobs\":" +
                closedJobs +
                ","
        );


        out.print(
                "\"totalApplications\":" +
                totalApplications +
                ","
        );


        out.print(
                "\"jobs\":["
        );


        // =========================================
        // JOB LIST
        // =========================================

        for (
                int i = 0;
                i < jobs.size();
                i++
        ) {

            Job job =
                    jobs.get(i);


            out.print("{");


            // JOB ID

            out.print(
                    "\"jobId\":" +
                    job.getJobId() +
                    ","
            );


            // TITLE

            out.print(
                    "\"title\":\"" +
                    escapeJson(
                            job.getTitle()
                    ) +
                    "\","
            );


            // DESCRIPTION

            out.print(
                    "\"description\":\"" +
                    escapeJson(
                            job.getDescription()
                    ) +
                    "\","
            );


            // LOCATION

            out.print(
                    "\"location\":\"" +
                    escapeJson(
                            job.getLocation()
                    ) +
                    "\","
            );


            // POSTED DATE

            out.print(
                    "\"postedDate\":\"" +
                    (
                        job.getPostedDate() != null
                        ? job.getPostedDate().toString()
                        : ""
                    ) +
                    "\","
            );


            // APPLICATION COUNT

            out.print(
                    "\"applicationCount\":" +
                    job.getApplicationCount()
            );


            out.print("}");


            if (
                i < jobs.size() - 1
            ) {

                out.print(",");

            }
        }


        out.print("]");

        out.print("}");

        out.flush();


        System.out.println(
                "Manage Jobs: SUCCESS"
        );

        System.out.println(
                "Jobs returned : " +
                jobs.size()
        );
    }


    // =========================================
    // JSON ESCAPE
    // =========================================

    private String escapeJson(
            String value) {

        if (value == null) {

            return "";
        }


        return value
                .replace(
                        "\\",
                        "\\\\"
                )
                .replace(
                        "\"",
                        "\\\""
                )
                .replace(
                        "\r",
                        "\\r"
                )
                .replace(
                        "\n",
                        "\\n"
                );
    }
}