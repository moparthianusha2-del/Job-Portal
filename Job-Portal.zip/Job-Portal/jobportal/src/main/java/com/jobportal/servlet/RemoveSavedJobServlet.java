package com.jobportal.servlet;

import com.jobportal.dao.SavedJobDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/RemoveSavedJobServlet")
public class RemoveSavedJobServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        try {

            String jobIdStr =
                    request.getParameter("jobId");

            System.out.println(
                    "Remove Job ID received = "
                    + jobIdStr
            );

            if (jobIdStr == null ||
                jobIdStr.trim().isEmpty()) {

                response.getWriter()
                        .print("missing_job_id");

                return;
            }

            int jobId =
                    Integer.parseInt(jobIdStr);

            // Temporary user ID
            // Session connection will be done later
            int userId = 262;

            SavedJobDAO dao =
                    new SavedJobDAO();

            boolean success =
                    dao.removeSavedJob(
                            userId,
                            jobId
                    );

            if (success) {

                response.getWriter()
                        .print("success");

            } else {

                response.getWriter()
                        .print("not_found");
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.getWriter()
                    .print("error");
        }
    }
}