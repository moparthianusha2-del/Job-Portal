package com.jobportal.model;

import java.sql.Date;

public class SavedJob {

    // ==============================
    // SAVED JOB TABLE FIELDS
    // ==============================

    private int saveId;
    private int userId;
    private int jobId;
    private Date savedDate;

    // ==============================
    // JOB TABLE FIELDS
    // ==============================

    private String jobTitle;
    private String description;
    private String location;


    // ==============================
    // DEFAULT CONSTRUCTOR
    // ==============================

    public SavedJob() {
    }


    // ==============================
    // SAVE ID
    // ==============================

    public int getSaveId() {
        return saveId;
    }

    public void setSaveId(int saveId) {
        this.saveId = saveId;
    }


    // ==============================
    // USER ID
    // ==============================

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }


    // ==============================
    // JOB ID
    // ==============================

    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }


    // ==============================
    // SAVED DATE
    // ==============================

    public Date getSavedDate() {
        return savedDate;
    }

    public void setSavedDate(Date savedDate) {
        this.savedDate = savedDate;
    }


    // ==============================
    // JOB TITLE
    // ==============================

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }


    // ==============================
    // DESCRIPTION
    // ==============================

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    // ==============================
    // LOCATION
    // ==============================

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}