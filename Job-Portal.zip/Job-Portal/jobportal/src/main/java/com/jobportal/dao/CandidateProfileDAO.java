package com.jobportal.dao;

import com.jobportal.db.DBConnection;
import com.jobportal.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CandidateProfileDAO {

    // =========================================================
    // GET CANDIDATE PROFILE
    // =========================================================

    public User getCandidateProfile(int seekerId) {

        User user = null;

        String sql =
                "SELECT USER_ID, NAME, EMAIL, PHONE, ROLE, COMPANY " +
                "FROM USERS " +
                "WHERE USER_ID = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, seekerId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                user = new User();

                user.setUserId(
                        rs.getInt("USER_ID")
                );

                user.setFullname(
                        rs.getString("NAME")
                );

                user.setEmail(
                        rs.getString("EMAIL")
                );

                user.setPhone(
                        rs.getString("PHONE")
                );

                user.setRole(
                        rs.getString("ROLE")
                );

                user.setCompany(
                        rs.getString("COMPANY")
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return user;
    }
}