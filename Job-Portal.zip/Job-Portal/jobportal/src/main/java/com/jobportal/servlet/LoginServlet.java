package com.jobportal.servlet;

import com.jobportal.dao.UserDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        // Get login details
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        System.out.println("========== LOGIN REQUEST ==========");
        System.out.println("Email : " + email);
        System.out.println("Role  : " + role);

        // Check login
        UserDAO dao = new UserDAO();
        User user = dao.login(email, password, role);

        if (user != null) {

            // Create session
            HttpSession session = request.getSession(true);

            // Store logged-in user
            session.setAttribute("loggedUser", user);

            // Debug information
            System.out.println("========== LOGIN SUCCESS ==========");
            System.out.println("User ID   : " + user.getUserId());
            System.out.println("Name      : " + user.getFullname());
            System.out.println("Email     : " + user.getEmail());
            System.out.println("Role      : " + user.getRole());
            System.out.println("SessionID : " + session.getId());

            // Redirect according to role
            if (role.equalsIgnoreCase("Employer")) {

                response.sendRedirect("employer_dashboard.html");

            } else {

                response.sendRedirect("js_dashboard.html");

            }

        } else {

            System.out.println("========== LOGIN FAILED ==========");
            System.out.println("Invalid Email / Password / Role");

            response.setContentType("text/html");

            response.getWriter().println(
                    "<script>" +
                    "alert('Invalid Email, Password or Role!');" +
                    "window.location='login.html';" +
                    "</script>"
            );
        }
    }
}