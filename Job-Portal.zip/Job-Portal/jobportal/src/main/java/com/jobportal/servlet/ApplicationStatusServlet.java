package com.jobportal.servlet;

import com.jobportal.dao.ApplicationDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/ApplicationStatusServlet")
public class ApplicationStatusServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // =========================================
        // GET PARAMETERS
        // =========================================

        String appIdParam = request.getParameter("appId");
        String status = request.getParameter("status");

        System.out.println("========== APPLICATION STATUS REQUEST ==========");
        System.out.println("APP_ID : " + appIdParam);
        System.out.println("STATUS : " + status);

        // =========================================
        // VALIDATION
        // =========================================

        if (appIdParam == null ||
            status == null ||
            appIdParam.trim().isEmpty() ||
            status.trim().isEmpty()) {

            response.setStatus(
                HttpServletResponse.SC_BAD_REQUEST
            );

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Invalid application details.\"}"
            );

            return;
        }

        int appId;

        try {

            appId = Integer.parseInt(appIdParam);

        } catch (NumberFormatException e) {

            response.setStatus(
                HttpServletResponse.SC_BAD_REQUEST
            );

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Invalid application ID.\"}"
            );

            return;
        }

        // =========================================
        // ALLOW ONLY VALID STATUS VALUES
        // =========================================

        if (!status.equalsIgnoreCase("SHORTLISTED") &&
            !status.equalsIgnoreCase("REJECTED")) {

            response.setStatus(
                HttpServletResponse.SC_BAD_REQUEST
            );

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Invalid status.\"}"
            );

            return;
        }

        status = status.toUpperCase();

        // =========================================
        // UPDATE DATABASE
        // =========================================

        ApplicationDAO dao = new ApplicationDAO();

        boolean success =
            dao.updateStatus(appId, status);

        // =========================================
        // RESPONSE
        // =========================================

        if (success) {

            System.out.println(
                "Application status updated successfully."
            );

            response.getWriter().print(
                "{\"success\":true,\"message\":\"Application status updated successfully.\"}"
            );

        } else {

            System.out.println(
                "Application status update failed."
            );

            response.setStatus(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            response.getWriter().print(
                "{\"success\":false,\"message\":\"Unable to update application status.\"}"
            );
        }
    }
}