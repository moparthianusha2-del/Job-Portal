package com.jobportal.servlet;

import com.jobportal.dao.ViewApplicationsDAO;
import com.jobportal.dao.ViewApplicationsDAO.ApplicationData;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/ViewApplicationsServlet")
public class ViewApplicationsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // =========================================
        // GET LOGGED-IN USER FROM SESSION
        // =========================================

        HttpSession session = request.getSession(false);

        if (session == null) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            response.getWriter().print(
                "{\"error\":\"Session expired. Please login again.\"}"
            );

            return;
        }

        Object obj = session.getAttribute("loggedUser");

        if (obj == null) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            response.getWriter().print(
                "{\"error\":\"User not logged in.\"}"
            );

            return;
        }

        User loggedUser = (User) obj;

        int employerId = loggedUser.getUserId();

        System.out.println(
            "View Applications - Employer ID: " + employerId
        );

        // =========================================
        // GET APPLICATIONS
        // =========================================

        ViewApplicationsDAO dao =
            new ViewApplicationsDAO();

        List<ApplicationData> applications =
            dao.getApplications(employerId);

        // =========================================
        // SEND JSON RESPONSE
        // =========================================

        PrintWriter out = response.getWriter();

        out.print("[");

        for (int i = 0; i < applications.size(); i++) {

            ApplicationData app = applications.get(i);

            if (i > 0) {
                out.print(",");
            }

            out.print("{");

            out.print("\"appId\":" + app.getAppId() + ",");

            out.print("\"seekerId\":" + app.getSeekerId() + ",");

            out.print("\"candidate\":\"" +
                escapeJson(app.getCandidate()) + "\",");

            out.print("\"email\":\"" +
                escapeJson(app.getEmail()) + "\",");

            out.print("\"jobTitle\":\"" +
                escapeJson(app.getJobTitle()) + "\",");

            out.print("\"resume\":\"" +
                escapeJson(app.getResume()) + "\",");

            out.print("\"status\":\"" +
                escapeJson(app.getStatus()) + "\",");

            out.print("\"applyDate\":\"" +
                (app.getApplyDate() != null
                    ? app.getApplyDate().toString()
                    : "") +
                "\"");

            out.print("}");
        }

        out.print("]");
    }


    // =========================================
    // ESCAPE JSON SPECIAL CHARACTERS
    // =========================================

    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"");
    }
}