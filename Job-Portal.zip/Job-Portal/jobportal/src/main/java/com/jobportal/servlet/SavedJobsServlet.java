package com.jobportal.servlet;

import com.jobportal.dao.SavedJobDAO;
import com.jobportal.model.SavedJob;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/SavedJobsServlet")
public class SavedJobsServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out =
                response.getWriter();

        try {

            // ============================================
            // GET CURRENT SESSION
            // ============================================

            HttpSession session =
                    request.getSession(false);


            if (session == null) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                        "{\"error\":\"User is not logged in\"}"
                );

                return;
            }


            // ============================================
            // GET LOGGED-IN USER
            // ============================================

            Object loggedUserObject =
                    session.getAttribute("loggedUser");


            if (loggedUserObject == null ||
                !(loggedUserObject instanceof User)) {

                response.setStatus(
                        HttpServletResponse.SC_UNAUTHORIZED
                );

                out.print(
                        "{\"error\":\"User session not found\"}"
                );

                return;
            }


            User loggedUser =
                    (User) loggedUserObject;


            int userId =
                    loggedUser.getUserId();


            System.out.println(
                    "================================="
            );

            System.out.println(
                    "Loading saved jobs"
            );

            System.out.println(
                    "Logged-in USER_ID = " + userId
            );

            System.out.println(
                    "================================="
            );


            // ============================================
            // GET SAVED JOBS FOR CURRENT USER
            // ============================================

            SavedJobDAO dao =
                    new SavedJobDAO();


            List<SavedJob> savedJobs =
                    dao.getSavedJobsByUser(userId);


            // ============================================
            // BUILD JSON
            // ============================================

            StringBuilder json =
                    new StringBuilder();


            json.append("[");


            for (int i = 0;
                 i < savedJobs.size();
                 i++) {

                SavedJob job =
                        savedJobs.get(i);


                json.append("{");


                json.append("\"saveId\":")
                    .append(job.getSaveId())
                    .append(",");


                json.append("\"userId\":")
                    .append(job.getUserId())
                    .append(",");


                json.append("\"jobId\":")
                    .append(job.getJobId())
                    .append(",");


                json.append("\"savedDate\":\"")
                    .append(
                        job.getSavedDate() != null
                            ? job.getSavedDate().toString()
                            : ""
                    )
                    .append("\",");


                json.append("\"jobTitle\":\"")
                    .append(
                        escapeJson(
                            job.getJobTitle()
                        )
                    )
                    .append("\",");


                json.append("\"description\":\"")
                    .append(
                        escapeJson(
                            job.getDescription()
                        )
                    )
                    .append("\",");


                json.append("\"location\":\"")
                    .append(
                        escapeJson(
                            job.getLocation()
                        )
                    )
                    .append("\"");


                json.append("}");


                if (i < savedJobs.size() - 1) {

                    json.append(",");

                }

            }


            json.append("]");


            out.print(
                    json.toString()
            );


        } catch (Exception e) {

            e.printStackTrace();


            response.setStatus(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );


            out.print(
                "{\"error\":\"Unable to load saved jobs\"}"
            );
        }
    }


    // ============================================
    // ESCAPE JSON
    // ============================================

    private String escapeJson(String value) {

        if (value == null) {

            return "";
        }


        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }
}