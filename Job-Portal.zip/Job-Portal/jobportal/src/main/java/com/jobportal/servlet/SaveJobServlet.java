package com.jobportal.servlet;

import java.io.IOException;

import com.jobportal.dao.SavedJobDAO;
import com.jobportal.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/SaveJobServlet")
public class SaveJobServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        try {

            // ============================================
            // GET JOB ID
            // ============================================

            String jobIdStr =
                    request.getParameter("jobId");

            System.out.println(
                    "Job ID received = " + jobIdStr
            );

            if (jobIdStr == null ||
                jobIdStr.trim().isEmpty()) {

                response.getWriter().print(
                        "Job ID is missing"
                );

                return;
            }

            int jobId =
                    Integer.parseInt(jobIdStr);


            // ============================================
            // GET LOGGED-IN USER FROM SESSION
            // ============================================

            HttpSession session =
                    request.getSession(false);


            if (session == null) {

                System.out.println(
                        "No active session found."
                );

                response.getWriter().print(
                        "not_logged_in"
                );

                return;
            }


            Object loggedUserObject =
                    session.getAttribute("loggedUser");


            if (loggedUserObject == null ||
                !(loggedUserObject instanceof User)) {

                System.out.println(
                        "loggedUser not found in session."
                );

                response.getWriter().print(
                        "not_logged_in"
                );

                return;
            }


            User loggedUser =
                    (User) loggedUserObject;


            int userId =
                    loggedUser.getUserId();


            System.out.println(
                    "Logged-in USER_ID = " + userId
            );


            // ============================================
            // SAVED JOB DAO
            // ============================================

            SavedJobDAO dao =
                    new SavedJobDAO();


            // ============================================
            // CHECK IF ALREADY SAVED
            // ============================================

            if (dao.isJobSaved(userId, jobId)) {

                System.out.println(
                        "Job already saved."
                );

                response.getWriter().print(
                        "already_saved"
                );

                return;
            }


            // ============================================
            // SAVE JOB FOR CURRENT USER
            // ============================================

            boolean success =
                    dao.saveJob(userId, jobId);


            if (success) {

                System.out.println(
                        "Job saved successfully."
                );

                System.out.println(
                        "USER_ID = " + userId +
                        ", JOB_ID = " + jobId
                );

                response.getWriter().print(
                        "success"
                );

            } else {

                System.out.println(
                        "Failed to save job."
                );

                response.getWriter().print(
                        "failed"
                );
            }


        } catch (NumberFormatException e) {

            e.printStackTrace();

            response.getWriter().print(
                    "Invalid Job ID"
            );


        } catch (Exception e) {

            e.printStackTrace();

            response.getWriter().print(
                    "error"
            );
        }
    }
}