package com.jobportal.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static final String URL =
        "jdbc:oracle:thin:@localhost:1521:XE";

    private static final String USER = "JOBPORTAL";
    private static final String PASSWORD = "job123";

    public static Connection getConnection() {

        try {

            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);

            System.out.println("Database Connected Successfully");

            return con;

        } catch (Exception e) {

            System.out.println("===== DATABASE CONNECTION FAILED =====");
            e.printStackTrace();

            return null;
        }
    }
}