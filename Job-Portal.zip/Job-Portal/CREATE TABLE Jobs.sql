CREATE TABLE JOBS
(
    JOB_ID NUMBER PRIMARY KEY,
    TITLE VARCHAR2(100) NOT NULL,
    DESCRIPTION VARCHAR2(500),
    LOCATION VARCHAR2(100),
    posted_date DATE,
    EMPLOYER_ID NUMBER NOT NULL
);
CREATE SEQUENCE JOBS_SEQ
START WITH 1
INCREMENT BY 1;
CREATE OR REPLACE TRIGGER JOBS_TRIGGER
BEFORE INSERT ON JOBS
FOR EACH ROW
BEGIN
    SELECT JOBS_SEQ.NEXTVAL
    INTO :NEW.JOB_ID
    FROM DUAL;
END;
/

INSERT INTO JOBS(JOB_ID ,
    TITLE ,
    DESCRIPTION ,
    LOCATION ,
    posted_date ,
    EMPLOYER_ID )
VALUES
(
    JOBS_SEQ.NEXTVAL,
    'Software Engineer',
    'Develop and maintain software applications.',
    'New York, NY',
    SYSDATE,
    1
);

INSERT ALL

INTO JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
VALUES
('Java Developer','Java Developer Required','Hyderabad',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),1)

INTO JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
VALUES
('Python Developer','Python Developer Required','Bangalore',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),2)

INTO JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
VALUES
('Web Developer','Frontend Developer','Chennai',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),3)

into JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
values
('Data Analyst','Data Analyst Required','Pune',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),4)

into JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
values
('DevOps Engineer','DevOps Engineer Required','Mumbai',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),5)

into JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
values
('UI/UX Designer','UI/UX Designer Required','Kolkata',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),6)

into JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
values
('Mobile App Developer','Mobile App Developer Required','Delhi',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),7)

into JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
values
('Database Administrator','Database Administrator Required','Chandigarh',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),8)

into JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
values
('Network Engineer','Network Engineer Required','Jaipur',TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)),9)

into JOBS
(TITLE, DESCRIPTION, LOCATION, posted_date, EMPLOYER_ID)
values
('Cloud Engineer','Cloud Engineer Required','Ahmedabad', TRUNC(DATE '2026-01-01' + DBMS_RANDOM.VALUE(0,180)), 10)

SELECT * FROM DUAL;

select * from JOBS;

select * from JOBS;

DESC JOBS;

SELECT JOB_ID,
       TITLE
FROM JOBS
ORDER BY JOB_ID;

SELECT * FROM JOBS;

SELECT *
FROM JOBS
WHERE JOB_ID = 43;

DESC JOBS;

DESC JOB_APPLICATIONS;

SELECT * FROM JOBS;

SELECT * FROM JOB_APPLICATIONS;

SELECT USER_ID, NAME, EMAIL, ROLE, COMPANY
FROM USERS
WHERE ROLE = 'EMPLOYER';

SELECT JOB_ID, TITLE, EMPLOYER_ID
FROM JOBS
ORDER BY JOB_ID;

SELECT USER_ID, NAME, EMAIL, ROLE, COMPANY
FROM USERS
ORDER BY USER_ID;

SELECT constraint_name,
       constraint_type
FROM user_constraints
WHERE table_name = 'JOBS';

SELECT constraint_name,
       constraint_type,
       search_condition
FROM user_constraints
WHERE table_name = 'JOBS';


UPDATE JOBS
SET EMPLOYER_ID =
    CASE JOB_ID
        WHEN 42 THEN 21
        WHEN 43 THEN 21
        WHEN 44 THEN 22
        WHEN 45 THEN 22
        WHEN 46 THEN 23
        WHEN 47 THEN 23
        WHEN 48 THEN 248
        WHEN 49 THEN 248
        WHEN 50 THEN 259
        WHEN 51 THEN 259
        WHEN 52 THEN 259
    END
WHERE JOB_ID IN (42,43,44,45,46,47,48,49,50,51,52);

commit;

SELECT JOB_ID, TITLE, EMPLOYER_ID
FROM JOBS
ORDER BY JOB_ID;

ALTER TABLE JOBS
ADD CONSTRAINT FK_JOBS_EMPLOYER
FOREIGN KEY (EMPLOYER_ID)
REFERENCES USERS(USER_ID);

SELECT constraint_name,
       constraint_type
FROM user_constraints
WHERE table_name = 'JOBS';

SELECT JOB_ID, TITLE, EMPLOYER_ID
FROM JOBS
ORDER BY JOB_ID;

SELECT *
FROM JOBS
ORDER BY JOB_ID DESC;

DESC SAVED_JOBS;